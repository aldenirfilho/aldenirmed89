# FocusAI Reader 360X — Changelog

## 8.0.0 · 16/11/2026 — Edição Limpa
- Reconstrução completa a partir da v7.1.1: código modular e ~60% menor.
- Leitor em iframe da própria extensão (isolado do CSS do site), modo tela cheia ou painel lateral.
- Marcação pela CSS Custom Highlight API: sem alterar o DOM, sem piscar; até 9 estilos editáveis (cor, opacidade, tipo, linha, espessura), caneta travada, borracha, anotações por marcação, atalhos 1–9.
- Âncoras por citação (trecho + contexto): marcações sobrevivem a troca de fonte, tema, biônica e quebra de parágrafos.
- Perfis prontos “TDAH” e “Dislexia”; holofote de parágrafo (J/K), régua, biônica, quebra de parágrafos longos, numeração, 6 temas, 5 fontes (OpenDyslexic, Lexend, Atkinson, sistema, serifada).
- Transcrição: cascata YouTube (faixa → painel) → VTT/TextTrack → painel com horários (Drive); legendas ao vivo; Whisper local; “seguir o vídeo”; capítulos ajustáveis.
- Conversão: importa SRT, VTT, SBV, ASS/SSA, TTML/DFXP/XML, JSON (YouTube, Whisper, FocusAI, Nexus) e TXT com horários; exporta TXT, MD, SRT, VTT, JSON e pacote Nexus.
- Ponte Nexus Capture: envio direto via mensagens entre extensões + pacote .json no formato de backup do Nexus; abre backups do Nexus no leitor.
- PDF → texto limpo no mesmo leitor (PDF.js), inclusive arrastando o arquivo.
- Biblioteca local com busca; ID de extensão fixo (legpmejabkphjdmkemblaeoccdcmpkak).
- Removidos para simplificar: calculadoras, flashcards, tradução, sons, pomodoro, visualizador paginado de PDF.
