/* ═══ Ponte FocusAI 360X — colar no FIM do background.js do Nexus Capture ═══
 * Depois de colar: ligue salvarCapturaNoNexus() à função que o Nexus já usa
 * para gravar uma captura (IndexedDB) e recarregue a extensão.
 */
const FOCUSAI_ID = 'legpmejabkphjdmkemblaeoccdcmpkak';

chrome.runtime.onMessageExternal.addListener((msg, sender, reply) => {
  if (sender.id !== FOCUSAI_ID) return false;

  if (msg?.type === 'NEXUS_PING') {
    reply({ ok: true, app: 'Nexus Capture', version: chrome.runtime.getManifest().version });
    return false;
  }

  if (msg?.type === 'NEXUS_IMPORT_CAPTURE' && msg.capture) {
    salvarCapturaNoNexus(msg.capture)
      .then(() => reply({ ok: true }))
      .catch(err => reply({ ok: false, error: String(err?.message || err) }));
    return true; // resposta assíncrona
  }
  return false;
});

/** Recebe uma captura no MESMO formato do backup do Nexus (schema aldenir-nexus-capture-backup). */
async function salvarCapturaNoNexus(capture) {
  // ⚠️ SUBSTITUA pela rotina real do Nexus, por exemplo:
  //   await saveCapture(capture);            // se existir
  //   await db.captures.put(capture);        // se usar IndexedDB direto
  throw new Error('Ponte instalada, mas salvarCapturaNoNexus() ainda não foi ligada ao banco do Nexus.');
}

/** Use no Nexus para abrir qualquer captura no leitor limpo do FocusAI. */
function abrirNoFocusAI(capture) {
  return chrome.runtime.sendMessage(FOCUSAI_ID, { type: 'FOCUSAI_OPEN_CAPTURE', capture });
}

/** Use no Nexus para mandar só a transcrição (trechos com tempo em segundos). */
function abrirTranscricaoNoFocusAI({ title, url, segments }) {
  return chrome.runtime.sendMessage(FOCUSAI_ID, { type: 'FOCUSAI_OPEN_TRANSCRIPT', title, url, segments });
}
