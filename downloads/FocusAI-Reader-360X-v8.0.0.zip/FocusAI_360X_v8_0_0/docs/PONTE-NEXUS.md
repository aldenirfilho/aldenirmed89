# 🔗 Ponte FocusAI 360X ⇄ Nexus Capture

| | ID da extensão |
|---|---|
| FocusAI 360X (fixo) | `legpmejabkphjdmkemblaeoccdcmpkak` |
| Nexus Capture (instalado em 02/11/2026) | `phmopnnkindeomkddkfjipjmnmhcemoo` |

## Dois caminhos

### 1 · Pacote .json (funciona hoje, sem mexer no Nexus)

- **FocusAI → Nexus:** `N` → **📦 Baixar pacote Nexus**. O arquivo segue o mesmo formato do backup do Nexus (`schema: aldenir-nexus-capture-backup`, `version: 1`, lista `captures`). Importe-o no Nexus pela opção de restaurar backup.
- **Nexus → FocusAI:** exporte o backup no Nexus (`NEXUS_CAPTURE_BACKUP_*.json`) ou uma transcrição (SRT, VTT, TXT…) e arraste o arquivo na Biblioteca do FocusAI, ou use `N` → **📂 Abrir backup**.

Cada captura enviada pelo FocusAI leva:

- `messages[0].text` e `html`: o texto (ou a transcrição com horários);
- `transcript.segments`: os trechos com `start`/`end` em segundos, quando for vídeo;
- `focusai.marks`: as marcações e anotações.

### 2 · Envio direto (precisa colar a ponte no Nexus Capture)

O FocusAI já envia e recebe mensagens. Falta o lado do Nexus responder.
Cole o arquivo `nexus-bridge-snippet.js` no fim do `background.js` do Nexus Capture
(projeto em `~/Documents/ChatGPT/NEXUS CAPTURE`) e ligue a função `salvarCapturaNoNexus`
à rotina que o Nexus já usa para gravar capturas no IndexedDB.

Depois recarregue o Nexus em `chrome://extensions`. No FocusAI, `N` deve mostrar
**✅ Nexus Capture conectado**.

## Mensagens

| Direção | `type` | Conteúdo |
|---|---|---|
| FocusAI → Nexus | `NEXUS_PING` | responde `{ ok:true, version }` |
| FocusAI → Nexus | `NEXUS_IMPORT_CAPTURE` | `{ capture }` no formato do backup |
| Nexus → FocusAI | `FOCUSAI_PING` | responde `{ ok:true, version, accepts }` |
| Nexus → FocusAI | `FOCUSAI_OPEN_CAPTURE` | `{ capture }` → abre no leitor limpo |
| Nexus → FocusAI | `FOCUSAI_OPEN_TRANSCRIPT` | `{ title, url, segments:[{start,end,text}] }` |
| Nexus → FocusAI | `FOCUSAI_OPEN_BACKUP` | `{ backup }` → lista as capturas |

O FocusAI só aceita mensagens do ID do Nexus configurado em `N` → **Avançado**.
