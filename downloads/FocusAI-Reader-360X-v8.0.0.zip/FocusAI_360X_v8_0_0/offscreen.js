/* FocusAI 360X v8.0.0 — captura de áudio da aba em documento offscreen */
'use strict';

let recorder = null;
let stream = null;
let chunks = [];
let audioContext = null;
let sourceNode = null;
let session = null;
let startedAt = 0;
let ticker = null;

const send = payload => chrome.runtime.sendMessage({ target:'background', ...payload }).catch(() => {});

function supportedMime() {
  const options = ['audio/webm;codecs=opus','audio/webm','audio/ogg;codecs=opus'];
  return options.find(type => MediaRecorder.isTypeSupported(type)) || '';
}

async function startCapture(message) {
  if (recorder && recorder.state !== 'inactive') throw new Error('Já existe uma gravação em andamento.');
  chunks = [];
  session = message.session;
  startedAt = Date.now();

  stream = await navigator.mediaDevices.getUserMedia({
    audio: { mandatory: { chromeMediaSource:'tab', chromeMediaSourceId:message.streamId } },
    video: false
  });

  audioContext = new AudioContext();
  sourceNode = audioContext.createMediaStreamSource(stream);
  sourceNode.connect(audioContext.destination);

  const mimeType = supportedMime();
  recorder = mimeType
    ? new MediaRecorder(stream, { mimeType, audioBitsPerSecond: 64000 })
    : new MediaRecorder(stream, { audioBitsPerSecond: 64000 });

  recorder.addEventListener('dataavailable', event => {
    if (event.data?.size) chunks.push(event.data);
  });
  recorder.addEventListener('error', event => {
    send({ type:'FAI_AUDIO_STATUS', tabId:session?.tabId, status:'error', message:event.error?.message || 'Erro de gravação.' });
  });
  recorder.start(10000);
  clearInterval(ticker);
  ticker = setInterval(() => {
    send({ type:'FAI_AUDIO_STATUS', tabId:session?.tabId, status:'recording', elapsed:Math.round((Date.now()-startedAt)/1000), chunks:chunks.length });
  }, 3000);
  send({ type:'FAI_AUDIO_STATUS', tabId:session.tabId, status:'recording', elapsed:0, message:'Capturando áudio da aba.' });
}

async function stopCapture() {
  if (!recorder || recorder.state === 'inactive') throw new Error('Nenhuma gravação ativa.');
  const current = recorder;
  await new Promise(resolve => {
    current.addEventListener('stop', resolve, { once:true });
    current.stop();
  });
  clearInterval(ticker);
  ticker = null;
  stream?.getTracks()?.forEach(track => track.stop());
  sourceNode?.disconnect?.();
  await audioContext?.close?.().catch(() => {});

  const mime = current.mimeType || 'audio/webm';
  const blob = new Blob(chunks, { type:mime });
  const localSession = session;
  recorder = null; stream = null; sourceNode = null; audioContext = null; session = null;

  if (!blob.size) throw new Error('A gravação terminou vazia.');
  send({ type:'FAI_AUDIO_STATUS', tabId:localSession.tabId, status:'uploading', bytes:blob.size, elapsed:Math.round((Date.now()-startedAt)/1000), message:'Enviando ao Whisper local.' });

  const form = new FormData();
  form.append('file', blob, `focusai-${Date.now()}.webm`);
  form.append('language', localSession.language || 'auto');
  form.append('model', localSession.model || 'small');
  form.append('title', localSession.title || 'Vídeo');
  form.append('source_url', localSession.url || '');

  const endpoint = String(localSession.endpoint || 'http://127.0.0.1:8765').replace(/\/$/, '');
  const response = await fetch(`${endpoint}/transcribe`, { method:'POST', body:form });
  const result = await response.json().catch(() => ({}));
  if (!response.ok || !result?.ok) throw new Error(result?.error || `Whisper local respondeu ${response.status}.`);
  send({ type:'FAI_AUDIO_RESULT', tabId:localSession.tabId, result, elapsed:Math.round((Date.now()-startedAt)/1000) });
  chunks = [];
}

async function cancelCapture() {
  clearInterval(ticker); ticker = null;
  try { if (recorder && recorder.state !== 'inactive') recorder.stop(); } catch {}
  stream?.getTracks()?.forEach(track => track.stop());
  sourceNode?.disconnect?.();
  await audioContext?.close?.().catch(() => {});
  recorder = null; stream = null; chunks = []; sourceNode = null; audioContext = null; session = null;
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.target !== 'offscreen') return false;
  if (message.type === 'FAI_OFF_START') {
    startCapture(message).then(() => sendResponse({ ok:true })).catch(error => {
      send({ type:'FAI_AUDIO_STATUS', tabId:message.session?.tabId, status:'error', message:String(error?.message || error) });
      sendResponse({ ok:false, error:String(error?.message || error) });
    });
    return true;
  }
  if (message.type === 'FAI_OFF_STOP') {
    stopCapture().catch(error => {
      send({ type:'FAI_AUDIO_STATUS', tabId:message.tabId, status:'error', message:String(error?.message || error) });
    });
    sendResponse({ ok:true, processing:true });
    return true;
  }
  if (message.type === 'FAI_OFF_CANCEL') {
    cancelCapture().then(() => sendResponse({ ok:true }));
    return true;
  }
  return false;
});
