/* FocusAI 360X v8.0.0 — motor de transcrição, conversão e formato Nexus (sem dependências) */
(() => {
  'use strict';
  if (globalThis.FAIEngine) return;

  const VERSION = '8.0.0';
  const NEXUS_SCHEMA = 'aldenir-nexus-capture-backup';

  const space = v => String(v ?? '').replace(/ /g, ' ').replace(/[ \t]+/g, ' ').replace(/\s*\n\s*/g, ' ').replace(/\s{2,}/g, ' ').trim();

  function decode(v) {
    const s = String(v || '');
    if (typeof DOMParser !== 'undefined') {
      try { return new DOMParser().parseFromString(`<textarea>${s}</textarea>`, 'text/html').querySelector('textarea').value; } catch {}
    }
    return s.replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;/g, "'");
  }

  const cleanText = v => space(decode(String(v || '').replace(/<br\s*\/?>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\{\\[^}]*\}/g, '')));

  function toSec(v) {
    if (typeof v === 'number' && Number.isFinite(v)) return Math.max(0, v);
    const raw = String(v || '').trim().replace(',', '.');
    if (!raw) return 0;
    if (/^\d+(\.\d+)?(ms|s|m|h)$/.test(raw)) {
      const n = parseFloat(raw); const u = raw.replace(/[\d.]/g, '');
      return u === 'ms' ? n / 1000 : u === 'm' ? n * 60 : u === 'h' ? n * 3600 : n;
    }
    const p = raw.split(':').map(Number);
    if (p.some(Number.isNaN)) return 0;
    if (p.length === 4) return p[0] * 3600 + p[1] * 60 + p[2] + p[3] / 30;
    if (p.length === 3) return p[0] * 3600 + p[1] * 60 + p[2];
    if (p.length === 2) return p[0] * 60 + p[1];
    return p[0] || 0;
  }

  function fmt(sec, mode = 'clock') {
    const s = Math.max(0, Number(sec) || 0);
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = Math.floor(s % 60);
    const ms = Math.round((s - Math.floor(s)) * 1000) % 1000;
    const p2 = n => String(n).padStart(2, '0');
    if (mode === 'srt') return `${p2(h)}:${p2(m)}:${p2(x)},${String(ms).padStart(3, '0')}`;
    if (mode === 'vtt') return `${p2(h)}:${p2(m)}:${p2(x)}.${String(ms).padStart(3, '0')}`;
    return h ? `${h}:${p2(m)}:${p2(x)}` : `${p2(m)}:${p2(x)}`;
  }

  /** Une trechos curtos e remove repetições típicas de legendas automáticas. */
  function merge(input, opt = {}) {
    const maxGap = opt.maxGap ?? 1.2, maxChars = opt.maxChars ?? 480;
    const list = (Array.isArray(input) ? input : [])
      .map(it => ({ start: Math.max(0, +it.start || 0), end: Math.max(+it.end || +it.start || 0, +it.start || 0), text: cleanText(it.text), speaker: space(it.speaker || '') }))
      .filter(it => it.text)
      .sort((a, b) => a.start - b.start || a.end - b.end);
    const out = [];
    for (const seg of list) {
      const prev = out[out.length - 1];
      if (prev) {
        const a = prev.text.toLowerCase(), b = seg.text.toLowerCase();
        if (a === b || (b.startsWith(a) && seg.start - prev.start < 8)) { prev.text = seg.text.length >= prev.text.length ? seg.text : prev.text; prev.end = Math.max(prev.end, seg.end); continue; }
        if (a.endsWith(b) && seg.start - prev.start < 8) { prev.end = Math.max(prev.end, seg.end); continue; }
        // sobreposição parcial (rolagem de legenda ao vivo)
        const ov = overlap(prev.text, seg.text);
        if (ov > 12 && seg.start - prev.end < 4) { prev.text = prev.text + seg.text.slice(ov); prev.end = Math.max(prev.end, seg.end); continue; }
      }
      if (opt.join !== false && prev && prev.speaker === seg.speaker && seg.start - prev.end <= maxGap && prev.text.length + seg.text.length < maxChars && !/[.!?…]$/.test(prev.text)) {
        prev.text = `${prev.text} ${seg.text}`; prev.end = Math.max(prev.end, seg.end);
      } else out.push({ ...seg });
    }
    return out.map((s, i) => ({ id: `t${i + 1}`, ...s }));
  }

  function overlap(a, b) {
    const max = Math.min(a.length, b.length, 200);
    for (let n = max; n > 0; n--) if (a.slice(-n).toLowerCase() === b.slice(0, n).toLowerCase()) return n;
    return 0;
  }

  // ───────── Parsers ─────────
  function parseVTT(text) {
    const blocks = String(text || '').replace(/^﻿/, '').replace(/\r/g, '').split(/\n{2,}/);
    const segs = [];
    for (const block of blocks) {
      const lines = block.split('\n').map(l => l.trim()).filter(Boolean);
      const ti = lines.findIndex(l => /-->/.test(l));
      if (ti < 0) continue;
      const m = lines[ti].match(/([\d:.,]+)\s*-->\s*([\d:.,]+)/);
      if (!m) continue;
      const t = cleanText(lines.slice(ti + 1).join(' '));
      if (t) segs.push({ start: toSec(m[1]), end: toSec(m[2]), text: t });
    }
    return merge(segs, { maxGap: 0.4, maxChars: 420 });
  }
  const parseSRT = parseVTT;

  function parseSBV(text) {
    const segs = [];
    for (const block of String(text || '').replace(/\r/g, '').split(/\n{2,}/)) {
      const lines = block.split('\n');
      const m = (lines[0] || '').match(/^([\d:.]+),([\d:.]+)$/);
      if (m) segs.push({ start: toSec(m[1]), end: toSec(m[2]), text: lines.slice(1).join(' ') });
    }
    return merge(segs);
  }

  function parseXML(text) {
    const segs = [];
    try {
      const doc = new DOMParser().parseFromString(String(text || ''), 'text/xml');
      for (const n of doc.querySelectorAll('text, p')) {
        let s, e;
        if (n.hasAttribute('begin')) { s = toSec(n.getAttribute('begin')); e = n.hasAttribute('end') ? toSec(n.getAttribute('end')) : s + toSec(n.getAttribute('dur') || 2); }
        else if (n.hasAttribute('t')) { s = +n.getAttribute('t') / 1000; e = s + (+n.getAttribute('d') || 2000) / 1000; }
        else { s = +n.getAttribute('start') || 0; e = s + (+n.getAttribute('dur') || 2); }
        const t = cleanText(n.textContent);
        if (t) segs.push({ start: s, end: e, text: t });
      }
    } catch {}
    return merge(segs);
  }

  function parseYTJson3(data) {
    const j = typeof data === 'string' ? JSON.parse(data) : data;
    const segs = [];
    for (const ev of j?.events || []) {
      if (!ev?.segs?.length) continue;
      const t = cleanText(ev.segs.map(s => s.utf8 || '').join(''));
      if (!t) continue;
      const s = (+ev.tStartMs || 0) / 1000;
      segs.push({ start: s, end: s + Math.max(0.3, (+ev.dDurationMs || 0) / 1000), text: t });
    }
    return merge(segs, { maxGap: 0.5, maxChars: 430 });
  }

  function parseASS(text) {
    const segs = [];
    for (const line of String(text || '').split(/\r?\n/)) {
      const m = line.match(/^Dialogue:\s*[^,]*,([^,]+),([^,]+),(?:[^,]*,){6}(.*)$/);
      if (m) segs.push({ start: toSec(m[1]), end: toSec(m[2]), text: m[3].replace(/\\N/g, ' ') });
    }
    return merge(segs);
  }

  /** TXT com horários no começo da linha ("00:12 texto" ou "[1:02:03] texto"). Sem horários → blocos sem tempo. */
  function parseTXT(text) {
    const lines = String(text || '').replace(/\r/g, '').split('\n');
    const segs = []; let cur = null;
    for (const raw of lines) {
      const line = raw.trim();
      if (!line) continue;
      const m = line.match(/^\[?((?:\d{1,2}:)?\d{1,2}:\d{2}(?:[.,]\d+)?)\]?\s*[-–—:]?\s*(.*)$/);
      if (m) { cur = { start: toSec(m[1]), end: toSec(m[1]) + 3, text: m[2] }; segs.push(cur); }
      else if (/^((?:\d{1,2}:)?\d{1,2}:\d{2})$/.test(line)) { cur = { start: toSec(line), end: toSec(line) + 3, text: '' }; segs.push(cur); }
      else if (cur) cur.text += ' ' + line;
      else segs.push(cur = { start: 0, end: 0, text: line, untimed: true });
    }
    for (let i = 0; i < segs.length - 1; i++) if (!segs[i].untimed && segs[i + 1].start > segs[i].start) segs[i].end = segs[i + 1].start;
    return merge(segs, { join: false });
  }

  function parseJSON(text) {
    const j = typeof text === 'string' ? JSON.parse(text) : text;
    if (j?.events) return { segments: parseYTJson3(j) };
    if (j?.schema === NEXUS_SCHEMA) return { nexus: j };
    if (j?.schema === 'focusai-transcript' || j?.schema === 'focusai-360x-transcript') return { segments: merge(j.segments || []), title: j.title, url: j.url };
    if (Array.isArray(j?.segments)) return { segments: merge(j.segments), title: j.title, url: j.url || j.source_url };
    if (Array.isArray(j)) return { segments: merge(j.map(x => ({ start: x.start ?? x.offset ?? 0, end: x.end ?? ((x.start ?? x.offset ?? 0) + (x.duration ?? 2)), text: x.text ?? x.content ?? '' }))) };
    throw new Error('JSON sem trechos de transcrição reconhecíveis.');
  }

  /** Detecta o formato pelo nome/conteúdo e devolve { segments, title?, nexus? }. */
  function parseAny(text, filename = '') {
    const name = filename.toLowerCase();
    const head = String(text || '').trimStart().slice(0, 300);
    if (name.endsWith('.json') || /^[[{]/.test(head)) return parseJSON(text);
    if (name.endsWith('.vtt') || /^WEBVTT/.test(head)) return { segments: parseVTT(text) };
    if (name.endsWith('.srt') || /^\d+\s*\n\d{2}:\d{2}:\d{2},\d{3}\s*-->/.test(head)) return { segments: parseSRT(text) };
    if (name.endsWith('.sbv') || /^\d+:\d{2}:\d{2}\.\d{3},\d+:\d{2}:\d{2}\.\d{3}/.test(head)) return { segments: parseSBV(text) };
    if (/\.(ass|ssa)$/.test(name) || /\[Script Info\]/.test(head)) return { segments: parseASS(text) };
    if (/\.(xml|ttml|dfxp)$/.test(name) || /^<\?xml|<tt[\s>]|<transcript/.test(head)) return { segments: parseXML(text) };
    return { segments: parseTXT(text) };
  }

  // ───────── Exportadores ─────────
  const toTXT = (segs, ts = true) => (segs || []).map(s => `${ts && !s.untimed ? `[${fmt(s.start)}] ` : ''}${s.speaker ? s.speaker + ': ' : ''}${s.text}`).join('\n\n') + '\n';
  const toSRT = segs => (segs || []).map((s, i) => `${i + 1}\n${fmt(s.start, 'srt')} --> ${fmt(Math.max(s.end, s.start + 1.2), 'srt')}\n${s.text}`).join('\n\n') + '\n';
  const toVTT = segs => 'WEBVTT\n\n' + (segs || []).map(s => `${fmt(s.start, 'vtt')} --> ${fmt(Math.max(s.end, s.start + 1.2), 'vtt')}\n${s.text}`).join('\n\n') + '\n';

  function chapters(segs, minutes = 5) {
    const size = Math.max(1, minutes) * 60; const out = [];
    for (const s of segs || []) {
      const i = Math.floor(s.start / size);
      (out[i] ||= { start: i * size, end: (i + 1) * size, segments: [] }).segments.push(s);
    }
    return out.filter(Boolean);
  }

  function toMD(segs, meta = {}) {
    const lines = [`# ${meta.title || 'Transcrição'}`, ''];
    if (meta.url) lines.push(`Fonte: ${meta.url}`, '');
    lines.push(`_Exportado pelo FocusAI 360X v${VERSION} em ${new Date().toLocaleString('pt-BR')}_`, '');
    for (const ch of chapters(segs, meta.chapterMinutes || 5)) {
      lines.push(`## ⏱ ${fmt(ch.start)} – ${fmt(ch.end)}`, '');
      for (const s of ch.segments) lines.push(`- **${fmt(s.start)}** ${s.text}`);
      lines.push('');
    }
    return lines.join('\n');
  }

  const toJSON = (segs, meta = {}) => JSON.stringify({ schema: 'focusai-360x-transcript', version: VERSION, title: meta.title || '', url: meta.url || '', createdAt: new Date().toISOString(), segments: segs || [] }, null, 2);

  /** Agrupa trechos em parágrafos legíveis (~45 s ou ~420 caracteres). */
  function paragraphs(segs, opt = {}) {
    const span = opt.seconds ?? 45, maxChars = opt.maxChars ?? 420; const out = [];
    for (const s of segs || []) {
      const p = out[out.length - 1];
      if (p && s.start - p.start < span && p.text.length + s.text.length < maxChars) { p.text += ' ' + s.text; p.end = s.end; }
      else out.push({ start: s.start, end: s.end, text: s.text });
    }
    return out;
  }

  // ───────── Formato Nexus Capture ─────────
  const rid = p => `${p}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`;
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  /** Monta uma captura compatível com o backup do Nexus Capture (schema aldenir-nexus-capture-backup v1). */
  function toNexusCapture({ title, url, html, text, segments, marks, kind }) {
    let host = ''; try { host = new URL(url).hostname; } catch {}
    const isTx = Array.isArray(segments) && segments.length > 0;
    const body = isTx ? toTXT(segments) : (text || '');
    const bodyHtml = isTx
      ? paragraphs(segments).map(p => `<p><strong>[${fmt(p.start)}]</strong> ${esc(p.text)}</p>`).join('\n')
      : (html || `<p>${esc(body)}</p>`);
    const words = (body.match(/\S+/g) || []).length;
    const now = new Date().toISOString();
    const msg = { id: rid('msg-1'), role: isTx ? 'transcript' : 'article', roleLabel: isTx ? 'Transcrição' : 'Página', title: isTx ? 'Transcrição' : 'Página', html: bodyHtml, text: body, wordCount: words, charCount: body.length, links: 0, images: 0, generatedImages: 0, imageDetails: [], truncated: false };
    const cap = {
      id: rid('capture'), kind: kind || (isTx ? 'transcript' : 'article'), siteType: isTx ? 'video' : 'page', title: title || 'Sem título', source: url || '', sourceHost: host,
      createdAt: now, messages: [msg], imageGallery: [],
      stats: { totalCaptured: 1, totalSelected: 1, words, characters: body.length, links: 0, images: 0, readingMinutes: Math.max(1, Math.round(words / 200)), truncated: false, truncationReasons: [] },
      version: `focusai-${VERSION}`, updatedAt: now,
      focusai: { origin: 'FocusAI 360X', version: VERSION }
    };
    if (isTx) { cap.transcript = { segments, language: '', provider: 'focusai' }; }
    if (marks?.length) cap.focusai.marks = marks.map(m => ({ text: m.quote, note: m.note || '', style: m.style }));
    return cap;
  }

  const toNexusBackup = captures => JSON.stringify({ schema: NEXUS_SCHEMA, version: 1, createdAt: new Date().toISOString(), captures }, null, 2);

  /** Lê uma captura Nexus e devolve algo que o leitor sabe abrir. */
  function fromNexusCapture(cap) {
    const msgs = cap?.messages || [];
    const segs = cap?.transcript?.segments || cap?.segments;
    if (Array.isArray(segs) && segs.length) return { kind: 'transcript', title: cap.title, url: cap.source, segments: merge(segs) };
    const html = msgs.map(m => (msgs.length > 1 ? `<h2>${esc(m.roleLabel || m.title || '')}</h2>` : '') + (m.html || `<p>${esc(m.text || '')}</p>`)).join('\n');
    const allText = msgs.map(m => m.text || '').join('\n');
    // transcrição salva como texto com horários
    if (/^\s*\[?\d{1,2}:\d{2}/.test(allText) && (allText.match(/\d{1,2}:\d{2}/g) || []).length > 5) {
      const parsed = parseTXT(allText);
      if (parsed.length > 3) return { kind: 'transcript', title: cap.title, url: cap.source, segments: parsed };
    }
    return { kind: 'article', title: cap.title, url: cap.source, html };
  }

  globalThis.FAIEngine = {
    VERSION, NEXUS_SCHEMA, space, cleanText, toSec, fmt, merge, esc,
    parseVTT, parseSRT, parseSBV, parseXML, parseYTJson3, parseASS, parseTXT, parseJSON, parseAny,
    toTXT, toSRT, toVTT, toMD, toJSON, chapters, paragraphs,
    toNexusCapture, toNexusBackup, fromNexusCapture
  };
})();
