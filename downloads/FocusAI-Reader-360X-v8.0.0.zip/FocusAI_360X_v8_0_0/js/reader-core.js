/* FocusAI 360X v8.0.0 — núcleo do leitor: documento, tipografia, marcações (CSS Custom Highlight API) */
(() => {
  'use strict';
  const E = globalThis.FAIEngine;
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const params = new URLSearchParams(location.search);
  const EMBED = params.get('embed') === '1';
  const app = $('#app'), docEl = $('#doc'), scrollEl = $('#scroll');

  // ───────────────── Preferências ─────────────────
  const DEFAULT_PRESETS = [
    { id: 'p1', name: 'Amarelo', kind: 'hl', color: '#FFD43B', alpha: 0.55, line: 'solid', thick: 2 },
    { id: 'p2', name: 'Verde', kind: 'hl', color: '#69DB7C', alpha: 0.45, line: 'solid', thick: 2 },
    { id: 'p3', name: 'Azul', kind: 'hl', color: '#74C0FC', alpha: 0.5, line: 'solid', thick: 2 },
    { id: 'p4', name: 'Rosa', kind: 'hl', color: '#F783AC', alpha: 0.42, line: 'solid', thick: 2 },
    { id: 'p5', name: 'Sublinhado preto', kind: 'ul', color: '#111111', alpha: 1, line: 'solid', thick: 2 },
    { id: 'p6', name: 'Ondulado vermelho', kind: 'ul', color: '#E03131', alpha: 1, line: 'wavy', thick: 2 },
    { id: 'p7', name: 'Duplo azul', kind: 'ul', color: '#1971C2', alpha: 1, line: 'double', thick: 2 },
    { id: 'p8', name: 'Conceito-chave', kind: 'hlul', color: '#FAB005', alpha: 0.35, line: 'solid', thick: 3, ucolor: '#B8860B' }
  ];
  const DEFAULT_PREFS = {
    font: 'od', size: 20, lh: 1.85, ls: 0, ws: 0.08, measure: 64, pgap: 1.15, theme: 'pergaminho',
    bionic: false, spotlight: false, ruler: false, chunk: true, numbered: false, palette: true, penLock: false,
    activePreset: 'p1', presets: DEFAULT_PRESETS, nexusId: '', wpm: 200, chapterMin: 5, follow: true,
    whisper: { endpoint: 'http://127.0.0.1:8765', model: 'small', language: 'pt' }
  };
  const FONTS = {
    od: { label: 'OpenDyslexic', css: "'OpenDyslexic', 'Lexend', sans-serif", cls: 'font-od' },
    lx: { label: 'Lexend', css: "'Lexend', system-ui, sans-serif", cls: 'font-lx' },
    at: { label: 'Atkinson', css: "'Atkinson', system-ui, sans-serif", cls: 'font-at' },
    sy: { label: 'Sistema', css: "system-ui, -apple-system, 'Segoe UI', sans-serif", cls: '' },
    se: { label: 'Serifada', css: "Georgia, 'Iowan Old Style', serif", cls: 'font-se' }
  };
  const THEMES = { pergaminho: 'Pergaminho', papel: 'Papel', sepia: 'Sépia', menta: 'Menta', noite: 'Noite', obsidiana: 'Obsidiana' };

  const S = {
    prefs: structuredClone(DEFAULT_PREFS), doc: null, view: 'article', record: null,
    marks: [], ranges: new Map(), index: null, erasing: false, focus: false, activePara: null, words: 0
  };

  const store = {
    get: async k => (await chrome.storage.local.get(k))[k],
    set: (k, v) => chrome.storage.local.set({ [k]: v }),
    del: k => chrome.storage.local.remove(k)
  };
  let prefTimer = 0;
  function savePrefs() { clearTimeout(prefTimer); prefTimer = setTimeout(() => store.set('fai8:prefs', S.prefs), 250); }

  // ───────────────── Utilidades ─────────────────
  function toast(msg, ms = 2600) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(t._t); t._t = setTimeout(() => t.classList.remove('show'), ms); }
  const esc = E.esc;
  const tabCmd = cmd => chrome.runtime.sendMessage({ type: 'FAI_TAB_CMD', cmd }).catch(e => ({ ok: false, error: e.message }));
  function download(name, text, type = 'text/plain;charset=utf-8') {
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type })); a.download = name;
    document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
  }
  const slug = s => String(s || 'documento').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w]+/g, '_').replace(/^_|_$/g, '').slice(0, 60) || 'documento';
  function hexA(hex, a) { const h = hex.replace('#', ''); const n = parseInt(h.length === 3 ? h.replace(/./g, c => c + c) : h, 16); return `rgba(${n >> 16 & 255}, ${n >> 8 & 255}, ${n & 255}, ${a})`; }
  function normUrl(u) {
    try { const x = new URL(u); x.hash = ''; if (/youtube\.com$/.test(x.hostname) && x.searchParams.get('v')) return `https://www.youtube.com/watch?v=${x.searchParams.get('v')}`; ['utm_source', 'utm_medium', 'utm_campaign', 'fbclid', 'gclid'].forEach(p => x.searchParams.delete(p)); return x.href; } catch { return u || ''; }
  }

  // ───────────────── Sanitização do HTML recebido ─────────────────
  const KEEP = new Set('a abbr b blockquote br caption cite code col colgroup dd del details dfn div dl dt em figcaption figure h1 h2 h3 h4 h5 h6 hr i img ins kbd li mark ol p pre q s samp small span strong sub summary sup table tbody td tfoot th thead time tr u ul'.split(' '));
  const DROP = new Set('script style link meta iframe object embed form input button select textarea noscript template canvas audio video source track svg math nav footer aside header'.split(' '));
  function sanitize(html, base) {
    const d = new DOMParser().parseFromString(`<body>${html || ''}</body>`, 'text/html');
    const walk = node => {
      for (const el of [...node.children]) {
        const tag = el.tagName.toLowerCase();
        if (DROP.has(tag)) { el.remove(); continue; }
        walk(el);
        if (!KEEP.has(tag)) { const map = { section: 'div', article: 'div', main: 'div', center: 'div' }; if (map[tag]) { const n = d.createElement(map[tag]); n.append(...el.childNodes); el.replaceWith(n); } else el.replaceWith(...el.childNodes); continue; }
        for (const at of [...el.attributes]) {
          const n = at.name.toLowerCase(), ok = (tag === 'a' && (n === 'href' || n === 'title')) || (tag === 'img' && ['src', 'alt', 'title'].includes(n)) || (['td', 'th'].includes(tag) && ['colspan', 'rowspan'].includes(n)) || (tag === 'ol' && n === 'start');
          if (!ok) el.removeAttribute(at.name);
        }
        if (tag === 'a') { const h = el.getAttribute('href') || ''; try { const u = new URL(h, base); if (!/^(https?:|mailto:)/.test(u.protocol)) el.removeAttribute('href'); else { el.setAttribute('href', u.href); el.setAttribute('target', '_blank'); el.setAttribute('rel', 'noopener noreferrer'); } } catch { el.removeAttribute('href'); } }
        if (tag === 'img') { const s = el.getAttribute('src') || ''; try { const u = new URL(s, base); if (!/^(https?:|data:)$/.test(u.protocol) || (u.protocol === 'data:' && !/^data:image\//.test(s))) el.remove(); else { el.setAttribute('src', u.href); el.setAttribute('loading', 'lazy'); } } catch { el.remove(); } }
        if (['div', 'span', 'p', 'li'].includes(tag) && !el.textContent.trim() && !el.querySelector('img,br,hr,table')) el.remove();
      }
    };
    walk(d.body);
    while (d.body.children.length === 1 && d.body.firstElementChild.tagName === 'DIV' && d.body.textContent.trim() === d.body.firstElementChild.textContent.trim()) d.body.firstElementChild.replaceWith(...d.body.firstElementChild.childNodes);
    // desembrulha divs que só envolvem outro bloco
    for (let i = 0; i < 3; i++) d.body.querySelectorAll('div').forEach(div => { if (div.children.length === 1 && !div.childNodes[0]?.textContent?.trim?.() && /^(DIV|P|UL|OL|TABLE|FIGURE)$/.test(div.firstElementChild.tagName) && div.textContent.trim() === div.firstElementChild.textContent.trim()) div.replaceWith(div.firstElementChild); });
    return d.body.innerHTML;
  }

  // ───────────────── Tipografia e tema ─────────────────
  function applyTypography() {
    const p = S.prefs, r = document.documentElement.style;
    r.setProperty('--font', (FONTS[p.font] || FONTS.od).css);
    r.setProperty('--size', `${p.size}px`); r.setProperty('--lh', p.lh); r.setProperty('--ls', `${p.ls}em`); r.setProperty('--ws', `${p.ws}em`);
    r.setProperty('--measure', `${p.measure}ch`); r.setProperty('--pgap', `${p.pgap}em`);
    app.className = app.className.replace(/theme-\S+/g, '').trim() + ` theme-${p.theme}`;
    app.classList.toggle('focus', S.focus);
    docEl.classList.toggle('spotlight', !!p.spotlight); docEl.classList.toggle('numbered', !!p.numbered); docEl.classList.toggle('bionic', !!p.bionic);
    $('#ruler').hidden = !p.ruler;
    $('#palette').hidden = !p.palette || app.dataset.mode === 'home';
    $('#btnFocus').classList.toggle('on', S.focus);
    renderPalette();
    if (S.doc && S.ranges.size) paintHighlights();
  }

  // ───────────────── Renderização do documento ─────────────────
  function transcriptHtml(segs) {
    const parts = [`<h1 class="doc-h1">${esc(S.doc.title || 'Transcrição')}</h1>`];
    if (S.doc.url) parts.push(`<p class="byline">🎬 ${esc(S.doc.url)} · ${segs.length} trechos</p>`);
    for (const ch of E.chapters(segs, S.prefs.chapterMin)) {
      parts.push(`<h2 class="tx-chapter">⏱ ${E.fmt(ch.start)} – ${E.fmt(ch.end)}</h2>`);
      for (const p of E.paragraphs(ch.segments)) parts.push(`<p class="tx-p" data-start="${p.start}" data-end="${p.end}"><button class="ts" data-t="${p.start}" title="Ir para este ponto do vídeo">${E.fmt(p.start)}</button>${esc(p.text)}</p>`);
    }
    return parts.join('\n');
  }

  function chunkParagraphs() {
    for (const p of $$('p', docEl)) {
      if (p.classList.contains('tx-p') || p.closest('li,td,blockquote')) continue;
      if ([...p.childNodes].some(n => n.nodeType !== 3)) continue;
      const words = (p.textContent.match(/\S+/g) || []).length;
      if (words < 75) continue;
      const sentences = p.textContent.split(/(?<=[.!?…])\s+(?=["“(]?[A-ZÁÉÍÓÚÂÊÔÃÕÀÇ0-9])/);
      if (sentences.length < 3) continue;
      const groups = []; let cur = '';
      for (const s of sentences) { if (cur && (cur + ' ' + s).split(/\s+/).length > 48) { groups.push(cur); cur = s; } else cur = cur ? cur + ' ' + s : s; }
      if (cur) groups.push(cur);
      if (groups.length < 2) continue;
      const frag = document.createDocumentFragment();
      groups.forEach((g, i) => { const n = document.createElement('p'); n.className = 'chunk'; n.textContent = g + (i < groups.length - 1 ? ' ' : ''); frag.appendChild(n); });
      p.replaceWith(frag);
    }
  }

  function applyBionic() {
    const walker = document.createTreeWalker(docEl, NodeFilter.SHOW_TEXT, { acceptNode: n => n.parentElement.closest('pre,code,.ts,h1,h2,h3,h4,a,b.bio') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    const nodes = []; let n; while ((n = walker.nextNode())) if (/\p{L}{2}/u.test(n.data)) nodes.push(n);
    for (const node of nodes) {
      const frag = document.createDocumentFragment();
      for (const part of node.data.split(/(\p{L}[\p{L}\p{M}'’-]*)/u)) {
        if (/^\p{L}/u.test(part) && part.length > 1) {
          const k = Math.max(1, Math.ceil(part.length * (part.length > 6 ? 0.4 : 0.5)));
          const b = document.createElement('b'); b.className = 'bio'; b.textContent = part.slice(0, k);
          frag.append(b, part.slice(k));
        } else if (part) frag.append(part);
      }
      node.replaceWith(frag);
    }
  }

  function renderView() {
    const d = S.doc; if (!d) return;
    const tx = S.view === 'transcript' && d.segments?.length;
    if (tx) docEl.innerHTML = transcriptHtml(d.segments);
    else docEl.innerHTML = `<h1 class="doc-h1">${esc(d.title || 'Sem título')}</h1>${d.byline ? `<p class="byline">${esc(d.byline)}</p>` : ''}${d.html || '<p><em>(sem texto)</em></p>'}`;
    if (!tx && S.prefs.chunk) chunkParagraphs();
    if (S.prefs.bionic) applyBionic();
    const BLK = 'p,li,h1,h2,h3,h4,h5,h6,blockquote,pre,figure,table,dt,dd';
    $$(BLK, docEl).forEach(el => { if (!el.parentElement.closest(BLK) && el.textContent.trim() || el.matches('figure')) el.classList.add('fai-block'); });
    $$('img', docEl).forEach(img => img.addEventListener('error', () => recoverImage(img), { once: true }));
    $('#viewTabs').hidden = !(d.segments?.length && d.html);
    $$('#viewTabs button').forEach(b => b.classList.toggle('on', b.dataset.view === S.view));
    S.words = (docEl.textContent.match(/\S+/g) || []).length;
    S.activePara = null;
    applyTypography();
    restoreMarks();
    updateProgress();
    FAI.emit('render');
  }

  async function recoverImage(img) {
    const src = img.getAttribute('src');
    if (!src || src.startsWith('data:')) return;
    const r = await chrome.runtime.sendMessage({ type: 'FAI_FETCH_DATAURL', url: src }).catch(() => null);
    if (r?.ok) img.src = r.dataUrl; else img.replaceWith(Object.assign(document.createElement('a'), { href: src, target: '_blank', textContent: `🖼 imagem (abrir no site)` }));
  }

  function updateMeta() {
    const pct = Math.round(progressPct() * 100);
    const left = Math.max(0, Math.ceil(S.words * (1 - progressPct()) / (S.prefs.wpm || 200)));
    $('#meta').textContent = S.doc ? `${pct}% · ${left} min restantes · ${S.marks.length} 🖍` : '';
  }
  const progressPct = () => { const max = scrollEl.scrollHeight - scrollEl.clientHeight; return max > 0 ? Math.min(1, scrollEl.scrollTop / max) : 1; };
  let posTimer = 0;
  function updateProgress() {
    $('#progress i').style.width = `${progressPct() * 100}%`; updateMeta();
    clearTimeout(posTimer); posTimer = setTimeout(() => { if (S.record) { S.record.scroll = progressPct(); persist(false); } }, 800);
  }

  // ───────────────── Índice de texto (âncoras de marcação) ─────────────────
  function buildIndex() {
    const nodes = []; let text = '';
    const w = document.createTreeWalker(docEl, NodeFilter.SHOW_TEXT, { acceptNode: n => n.parentElement.closest('.ts,[data-fai-ui]') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT });
    let n; while ((n = w.nextNode())) { nodes.push({ n, s: text.length }); text += n.data; }
    S.index = { nodes, text };
    return S.index;
  }
  function offsetOf(container, offset) {
    const { nodes } = S.index;
    const hit = nodes.find(x => x.n === container);
    if (hit) return hit.s + Math.min(offset, hit.n.data.length);
    const r = document.createRange(); r.setStart(container, offset);
    for (const x of nodes) if (r.comparePoint(x.n, 0) >= 0) return x.s;
    return S.index.text.length;
  }
  function rangeFrom(s, e) {
    const { nodes } = S.index; if (!nodes.length) return null;
    const find = (off, isEnd) => {
      let lo = 0, hi = nodes.length - 1;
      while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (nodes[mid].s < off || (!isEnd && nodes[mid].s === off)) lo = mid; else hi = mid - 1; }
      const x = nodes[lo]; return [x.n, Math.max(0, Math.min(off - x.s, x.n.data.length))];
    };
    try { const r = document.createRange(); r.setStart(...find(s, false)); r.setEnd(...find(e, true)); return r; } catch { return null; }
  }
  function locate(m) {
    const t = S.index.text;
    let best = -1, bestScore = -1;
    for (let i = t.indexOf(m.quote); i >= 0; i = t.indexOf(m.quote, i + 1)) {
      let sc = 0; const pre = t.slice(Math.max(0, i - m.prefix.length), i), suf = t.slice(i + m.quote.length, i + m.quote.length + m.suffix.length);
      for (let k = 1; k <= pre.length && pre[pre.length - k] === m.prefix[m.prefix.length - k]; k++) sc++;
      for (let k = 0; k < suf.length && suf[k] === m.suffix[k]; k++) sc++;
      sc -= Math.abs(i - (m.pos || 0)) / 1e6;
      if (sc > bestScore) { bestScore = sc; best = i; }
    }
    if (best >= 0) return [best, best + m.quote.length];
    // tolerância a espaços diferentes
    const map = []; let norm = '';
    for (let i = 0; i < t.length; i++) { const c = /\s/.test(t[i]) ? ' ' : t[i]; if (c === ' ' && norm.endsWith(' ')) continue; norm += c; map.push(i); }
    const q = m.quote.replace(/\s+/g, ' ').trim(); const j = norm.indexOf(q);
    return j >= 0 ? [map[j], map[j + q.length - 1] + 1] : null;
  }

  // ───────────────── Estilos de marcação → ::highlight() ─────────────────
  const styleSheet = new CSSStyleSheet(); document.adoptedStyleSheets = [...document.adoptedStyleSheets, styleSheet];
  const presetById = id => S.prefs.presets.find(p => p.id === id);
  function styleKey(st) { return 'fai-' + [st.kind, st.color, st.alpha, st.line, st.thick, st.ucolor || ''].join('_').replace(/[^\w]/g, ''); }
  const darkTheme = () => ['noite', 'obsidiana'].includes(S.prefs.theme);
  function styleCss(st) {
    const parts = [];
    if (st.kind === 'hl' || st.kind === 'hlul') parts.push(darkTheme() ? `background-color:${hexA(st.color, Math.max(0.82, st.alpha))};color:#14110B` : `background-color:${hexA(st.color, st.alpha)}`);
    if (st.kind === 'ul' || st.kind === 'hlul') parts.push(`text-decoration:underline ${st.line} ${st.kind === 'hlul' ? (st.ucolor || st.color) : st.color} ${st.thick}px`, 'text-decoration-skip-ink:none');
    if (st.kind === 'tx') parts.push(`color:${st.color}`, 'text-decoration:underline dotted ' + hexA(st.color, 0.6) + ' 1px');
    return parts.join(';');
  }
  function previewCss(st) {
    const p = [];
    if (st.kind === 'hl' || st.kind === 'hlul') p.push(`background:${hexA(st.color, Math.max(.35, st.alpha))}`);
    if (st.kind === 'ul' || st.kind === 'hlul') p.push(`text-decoration:underline ${st.line} ${st.kind === 'hlul' ? (st.ucolor || st.color) : st.color} ${st.thick}px; text-underline-offset:3px`);
    if (st.kind === 'tx') p.push(`color:${st.color}`);
    if (st.kind !== 'hl' && st.kind !== 'hlul') p.push('background:#FBF7EE');
    return p.join(';');
  }

  function paintHighlights() {
    if (!globalThis.CSS?.highlights) return;
    for (const k of [...CSS.highlights.keys()]) if (k.startsWith('fai-')) CSS.highlights.delete(k);
    const groups = new Map(); const rules = new Set();
    S.marks.forEach((m, i) => {
      const r = S.ranges.get(m.id); if (!r) return;
      const st = presetById(m.presetId) || m.style; const key = styleKey(st) + (darkTheme() ? 'd' : '');
      if (!groups.has(key)) { groups.set(key, { ranges: [], prio: i }); rules.add(`::highlight(${key}){${styleCss(st)}}`); }
      groups.get(key).ranges.push(r);
    });
    styleSheet.replaceSync([...rules].join('\n'));
    let prio = 1;
    for (const [key, g] of groups) { const h = new Highlight(...g.ranges); h.priority = prio++; CSS.highlights.set(key, h); }
    updateMeta();
  }

  function restoreMarks() {
    buildIndex(); S.ranges.clear();
    const lost = [];
    for (const m of S.marks) { const loc = locate(m); const r = loc && rangeFrom(...loc); if (r) S.ranges.set(m.id, r); else lost.push(m); }
    paintHighlights();
    if (lost.length) toast(`⚠️ ${lost.length} marcação(ões) não encontrada(s) neste texto (a página mudou).`);
  }

  // ───────────────── Persistência por documento ─────────────────
  function marksNs() { return S.view === 'transcript' ? 'tx' : 'article'; }
  async function persist(full = true) {
    if (!S.record) return;
    S.record.updated = Date.now();
    S.record.marks = S.record.marks || {};
    S.record.marks[marksNs()] = S.marks;
    const total = Object.values(S.record.marks).reduce((a, b) => a + (b?.length || 0), 0);
    const keep = total > 0 || S.doc.segments?.length || S.record.pinned;
    if (full && keep) { S.record.html = S.doc.html || ''; if (S.doc.segments?.length) S.record.segments = S.doc.segments; }
    if (keep) await store.set(`fai8:doc:${S.record.key}`, S.record);
  }

  async function loadDoc(doc, opts = {}) {
    S.doc = { kind: 'page', title: '', url: '', html: '', segments: null, ...doc };
    if (S.doc.html) S.doc.html = sanitize(S.doc.html, S.doc.url || location.href);
    const key = S.doc.key || (S.doc.url ? `${S.doc.kind === 'pdf' ? 'pdf:' : ''}${normUrl(S.doc.url)}` : `file:${slug(S.doc.title)}`);
    S.doc.key = key;
    const saved = await store.get(`fai8:doc:${key}`);
    S.record = saved || { key, title: S.doc.title, url: S.doc.url, kind: S.doc.kind, created: Date.now(), marks: {} };
    S.record.title = S.doc.title || S.record.title; S.record.kind = S.doc.kind;
    if (!S.doc.html && saved?.html) S.doc.html = saved.html;
    if (!S.doc.segments && saved?.segments?.length) S.doc.segments = saved.segments;
    S.view = opts.view || (S.doc.html ? 'article' : 'transcript');
    S.marks = (S.record.marks?.[marksNs()] || []).slice();
    $('#docTitle').textContent = S.doc.title || 'FocusAI 360X';
    document.title = `${S.doc.title || 'Leitor'} — FocusAI 360X`;
    app.dataset.mode = 'doc'; delete app.dataset.loading;
    renderView();
    if (saved?.scroll && !opts.noRestore) requestAnimationFrame(() => { scrollEl.style.scrollBehavior = 'auto'; scrollEl.scrollTop = saved.scroll * (scrollEl.scrollHeight - scrollEl.clientHeight); scrollEl.style.scrollBehavior = ''; });
    if (S.doc.segments?.length) persist(true);
  }

  function setView(v) {
    if (v === S.view) return;
    S.record.marks[marksNs()] = S.marks;
    S.view = v; S.marks = (S.record.marks?.[marksNs()] || []).slice();
    scrollEl.scrollTop = 0; renderView();
  }

  function setSegments(segs, meta = {}) {
    if (!S.doc) return loadDoc({ kind: 'transcript', title: meta.title || 'Transcrição', url: meta.url || '', segments: segs }, { view: 'transcript' });
    S.doc.segments = segs; if (!S.doc.title && meta.title) S.doc.title = meta.title;
    persist(true);
    if (S.view === 'transcript') renderView(); else setView('transcript');
  }

  // ───────────────── Criação / edição de marcações ─────────────────
  function selectionRange() {
    const sel = getSelection(); if (!sel || sel.isCollapsed || !sel.rangeCount) return null;
    const r = sel.getRangeAt(0); if (!docEl.contains(r.commonAncestorContainer)) return null;
    return r;
  }
  function addMark(range, presetId = S.prefs.activePreset) {
    buildIndex();
    let s = offsetOf(range.startContainer, range.startOffset), e = offsetOf(range.endContainer, range.endOffset);
    const t = S.index.text;
    while (s < e && /\s/.test(t[s])) s++; while (e > s && /\s/.test(t[e - 1])) e--;
    if (e - s < 1) return null;
    const same = S.marks.find(m => m.presetId === presetId && S.ranges.get(m.id) && Math.abs(offsetOf(S.ranges.get(m.id).startContainer, S.ranges.get(m.id).startOffset) - s) < 2 && Math.abs(offsetOf(S.ranges.get(m.id).endContainer, S.ranges.get(m.id).endOffset) - e) < 2);
    if (same) { removeMark(same.id); return null; }
    const preset = presetById(presetId) || S.prefs.presets[0];
    const m = { id: `m${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, quote: t.slice(s, e), prefix: t.slice(Math.max(0, s - 40), s), suffix: t.slice(e, e + 40), pos: s, presetId: preset.id, style: { ...preset }, note: '', created: Date.now() };
    if (S.doc.segments?.length && S.view === 'transcript') { const p = rangeFrom(s, e)?.startContainer?.parentElement?.closest('.tx-p'); if (p) m.t = +p.dataset.start; }
    S.marks.push(m); S.ranges.set(m.id, rangeFrom(s, e));
    paintHighlights(); persist(true);
    return m;
  }
  function removeMark(id) { S.marks = S.marks.filter(m => m.id !== id); S.ranges.delete(id); paintHighlights(); persist(true); FAI.emit('marks'); }
  function updateMark(id, patch) { const m = S.marks.find(x => x.id === id); if (!m) return; Object.assign(m, patch); if (patch.presetId) m.style = { ...presetById(patch.presetId) }; paintHighlights(); persist(true); FAI.emit('marks'); }
  function markAt(x, y) {
    for (let i = S.marks.length - 1; i >= 0; i--) {
      const r = S.ranges.get(S.marks[i].id); if (!r) continue;
      for (const b of r.getClientRects()) if (x >= b.left - 1 && x <= b.right + 1 && y >= b.top - 2 && y <= b.bottom + 2) return S.marks[i];
    }
    return null;
  }

  // ───────────────── Paleta, barra de seleção e pop ─────────────────
  function swatch(p, extra = '') { return `<button class="sw ${extra}" data-preset="${p.id}" title="${esc(p.name)}" style="${previewCss(p)}">A</button>`; }
  function renderPalette() {
    const box = $('#paletteSwatches'); if (!box) return;
    box.innerHTML = S.prefs.presets.map((p, i) => swatch(p, p.id === S.prefs.activePreset ? 'on' : '').replace('title="', `title="${i + 1} · `)).join('');
    $('#penLock').classList.toggle('on', !!S.prefs.penLock);
    $('#eraser').classList.toggle('on', S.erasing); app.classList.toggle('erasing', S.erasing);
  }
  function placeFloating(el, rect, below = false) {
    el.hidden = false;
    const w = el.offsetWidth, h = el.offsetHeight;
    let x = Math.min(window.innerWidth - w - 8, Math.max(8, rect.left + rect.width / 2 - w / 2));
    let y = below ? rect.bottom + 10 : rect.top - h - 10;
    if (y < 56) y = rect.bottom + 10; if (y + h > window.innerHeight - 8) y = Math.max(56, rect.top - h - 10);
    y = Math.max(56, Math.min(window.innerHeight - h - 8, y));
    el.style.left = `${x}px`; el.style.top = `${y}px`;
  }
  function showSelbar(range) {
    const bar = $('#selbar');
    bar.innerHTML = S.prefs.presets.map(p => swatch(p)).join('') + '<span class="sep"></span><button data-act="note" title="Marcar e anotar">📝</button><button data-act="copy" title="Copiar">📋</button><button data-act="search" title="Pesquisar no Google">🔎</button><button data-act="pubmed" title="Pesquisar no PubMed">PM</button>';
    placeFloating(bar, range.getBoundingClientRect());
  }
  const hideFloat = () => { $('#selbar').hidden = true; $('#markpop').hidden = true; };
  function showMarkPop(m, rect) {
    const pop = $('#markpop');
    pop.innerHTML = `<div class="quote">“${esc(m.quote.slice(0, 160))}${m.quote.length > 160 ? '…' : ''}”</div>
      <div class="row">${S.prefs.presets.map(p => swatch(p, p.id === m.presetId ? 'on' : '')).join('')}</div>
      <textarea placeholder="Anotação (salva automaticamente)…">${esc(m.note || '')}</textarea>
      <div class="row"><button data-act="copy">📋 Copiar</button>${m.t != null ? '<button data-act="seek">▶ Ir ao vídeo</button>' : ''}<button data-act="del" style="margin-left:auto">🗑 Apagar</button></div>`;
    pop.dataset.id = m.id;
    placeFloating(pop, rect, true);
  }

  let downAt = null;
  docEl.addEventListener('pointerdown', e => { downAt = { x: e.clientX, y: e.clientY, t: Date.now() }; hideFloat(); });
  document.addEventListener('pointerup', e => {
    const tgt = e.target instanceof Element ? e.target : docEl;
    if (tgt.closest('[data-fai-ui]') || app.dataset.mode !== 'doc') return;
    const moved = downAt && (Math.abs(e.clientX - downAt.x) + Math.abs(e.clientY - downAt.y) > 4);
    setTimeout(() => {
      const r = selectionRange();
      if (r) {
        if (S.erasing) { buildIndex(); const s = offsetOf(r.startContainer, r.startOffset), en = offsetOf(r.endContainer, r.endOffset); S.marks.filter(m => { const mr = S.ranges.get(m.id); if (!mr) return false; const ms = offsetOf(mr.startContainer, mr.startOffset), me = offsetOf(mr.endContainer, mr.endOffset); return ms < en && me > s; }).forEach(m => removeMark(m.id)); getSelection().removeAllRanges(); return; }
        if (S.prefs.penLock) { addMark(r); getSelection().removeAllRanges(); FAI.emit('marks'); return; }
        showSelbar(r); return;
      }
      if (!moved && tgt.closest('#doc')) {
        const m = markAt(e.clientX, e.clientY);
        if (m && S.erasing) { removeMark(m.id); toast('🧽 Marcação apagada'); return; }
        if (m) showMarkPop(m, new DOMRect(e.clientX, e.clientY, 1, 1));
      }
    }, 0);
  });
  // seleção por teclado (Shift+setas)
  document.addEventListener('keyup', e => { if (e.shiftKey && /Arrow|Home|End/.test(e.key)) { const r = selectionRange(); if (r) showSelbar(r); } });

  $('#selbar').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return;
    const r = selectionRange(); if (!r) return hideFloat();
    const text = r.toString();
    if (b.dataset.preset) { addMark(r, b.dataset.preset); S.prefs.activePreset = b.dataset.preset; savePrefs(); renderPalette(); getSelection().removeAllRanges(); hideFloat(); FAI.emit('marks'); return; }
    const act = b.dataset.act;
    if (act === 'note') { const m = addMark(r); getSelection().removeAllRanges(); hideFloat(); if (m) { showMarkPop(m, r.getBoundingClientRect()); setTimeout(() => $('#markpop textarea')?.focus(), 30); } FAI.emit('marks'); }
    if (act === 'copy') { navigator.clipboard.writeText(text).then(() => toast('📋 Copiado')); hideFloat(); }
    if (act === 'search') window.open(`https://www.google.com/search?q=${encodeURIComponent(text)}`, '_blank');
    if (act === 'pubmed') window.open(`https://pubmed.ncbi.nlm.nih.gov/?term=${encodeURIComponent(text)}`, '_blank');
  });
  $('#markpop').addEventListener('click', e => {
    const b = e.target.closest('button'); if (!b) return; const id = $('#markpop').dataset.id; const m = S.marks.find(x => x.id === id); if (!m) return;
    if (b.dataset.preset) { updateMark(id, { presetId: b.dataset.preset }); showMarkPop(m, b.closest('#markpop').getBoundingClientRect()); return; }
    if (b.dataset.act === 'del') { removeMark(id); hideFloat(); toast('🗑 Marcação apagada'); }
    if (b.dataset.act === 'copy') navigator.clipboard.writeText(m.quote).then(() => toast('📋 Copiado'));
    if (b.dataset.act === 'seek') FAI.seek(m.t);
  });
  let noteTimer = 0;
  $('#markpop').addEventListener('input', e => { if (e.target.tagName !== 'TEXTAREA') return; const id = $('#markpop').dataset.id; clearTimeout(noteTimer); noteTimer = setTimeout(() => updateMark(id, { note: e.target.value }), 350); });

  $('#paletteSwatches').addEventListener('click', e => {
    const b = e.target.closest('button[data-preset]'); if (!b) return;
    S.prefs.activePreset = b.dataset.preset; savePrefs();
    const r = selectionRange(); if (r) { addMark(r); getSelection().removeAllRanges(); hideFloat(); FAI.emit('marks'); }
    S.erasing = false; renderPalette();
  });
  $('#paletteSwatches').addEventListener('dblclick', e => { if (e.target.closest('button[data-preset]')) FAI.openPanel('marks'); });
  $('#penLock').addEventListener('click', () => { S.prefs.penLock = !S.prefs.penLock; S.erasing = false; savePrefs(); renderPalette(); toast(S.prefs.penLock ? '🔒 Caneta travada: selecione o texto e ele já fica marcado' : '🔓 Caneta livre: selecione e escolha a cor'); });
  $('#eraser').addEventListener('click', () => { S.erasing = !S.erasing; renderPalette(); toast(S.erasing ? '⌫ Borracha: clique ou passe sobre uma marcação' : 'Borracha desligada'); });

  // ───────────────── Foco: holofote, régua, navegação por parágrafo ─────────────────
  const blocks = () => $$('.fai-block', docEl).filter(el => !el.matches('h1.doc-h1'));
  function setActive(el, scroll = false) {
    if (S.activePara) S.activePara.classList.remove('fai-active');
    S.activePara = el; if (!el) return; el.classList.add('fai-active');
    if (scroll) el.scrollIntoView({ block: 'center', behavior: 'smooth' });
  }
  docEl.addEventListener('pointermove', e => {
    if (S.prefs.spotlight) { const el = e.target.closest('.fai-block'); if (el && el !== S.activePara) setActive(el); }
  });
  document.addEventListener('pointermove', e => { if (S.prefs.ruler) $('#ruler').style.top = `${e.clientY - $('#ruler').offsetHeight / 2}px`; });
  scrollEl.addEventListener('scroll', () => { updateProgress(); hideFloat(); }, { passive: true });
  function stepPara(dir) {
    const list = blocks(); if (!list.length) return;
    let i = S.activePara ? list.indexOf(S.activePara) : -1;
    if (i < 0) { const mid = window.innerHeight / 2; i = list.findIndex(el => el.getBoundingClientRect().bottom > mid) - (dir > 0 ? 1 : 0); }
    setActive(list[Math.max(0, Math.min(list.length - 1, i + dir))], true);
  }

  // ───────────────── Atalhos ─────────────────
  function closeReader() { if (EMBED) parent.postMessage({ fai: 'close' }, '*'); }
  document.addEventListener('keydown', e => {
    if (e.target.closest('input,textarea,select,[contenteditable]')) { if (e.key === 'Escape') e.target.blur(); return; }
    if (e.metaKey || e.ctrlKey || e.altKey) return;
    const k = e.key, P = S.prefs;
    const act = {
      Escape: () => { if (!$('#selbar').hidden || !$('#markpop').hidden) hideFloat(); else if (S.erasing) { S.erasing = false; renderPalette(); } else if ($('#drawer').classList.contains('open')) FAI.closePanel(); else if (S.focus) toggleFocus(); else closeReader(); },
      t: () => FAI.openPanel('typo'), m: () => FAI.openPanel('marks'), i: () => FAI.openPanel('toc'), v: () => FAI.openPanel('tx'), n: () => FAI.openPanel('nexus'), x: () => FAI.openPanel('export'), '?': () => FAI.openPanel('help'),
      f: () => toggleFocus(), r: () => { P.ruler = !P.ruler; savePrefs(); applyTypography(); }, s: () => { P.spotlight = !P.spotlight; savePrefs(); applyTypography(); if (P.spotlight) stepPara(0); },
      b: () => { P.bionic = !P.bionic; savePrefs(); renderView(); }, p: () => $('#penLock').click(), e: () => $('#eraser').click(),
      h: () => { const r = selectionRange(); if (r) { addMark(r); getSelection().removeAllRanges(); hideFloat(); FAI.emit('marks'); } else toast('Selecione um trecho e aperte H'); },
      '+': () => { P.size = Math.min(40, P.size + 1); savePrefs(); applyTypography(); }, '=': () => act['+'](), '-': () => { P.size = Math.max(12, P.size - 1); savePrefs(); applyTypography(); },
      j: () => stepPara(1), k: () => stepPara(-1)
    };
    if (/^[1-9]$/.test(k) && P.presets[+k - 1]) {
      P.activePreset = P.presets[+k - 1].id; savePrefs(); renderPalette();
      const r = selectionRange(); if (r) { addMark(r); getSelection().removeAllRanges(); hideFloat(); FAI.emit('marks'); } else toast(`🖍 ${P.presets[+k - 1].name}`);
      e.preventDefault(); return;
    }
    const fn = act[k] || act[k.toLowerCase()];
    if (fn) { e.preventDefault(); fn(); }
  });
  function toggleFocus() { S.focus = !S.focus; applyTypography(); if (S.focus) { FAI.closePanel(); toast('◉ Modo foco — passe o mouse no topo para ver a barra · F ou Esc para sair'); } }
  $('#btnFocus').addEventListener('click', toggleFocus);

  // ───────────────── Gaveta de painéis ─────────────────
  const panels = {};
  let current = null;
  function openPanel(name, refresh = false) {
    const p = panels[name]; if (!p) return;
    if (!refresh && current === name && $('#drawer').classList.contains('open')) return closePanel();
    current = name; $('#drawerTitle').textContent = p.title; const body = $('#drawerBody'); body.innerHTML = ''; p.render(body);
    $('#drawer').classList.add('open'); $('#drawer').setAttribute('aria-hidden', 'false');
    $$('#tools button[data-panel]').forEach(b => b.classList.toggle('on', b.dataset.panel === name));
  }
  function closePanel() { current = null; $('#drawer').classList.remove('open'); $('#drawer').setAttribute('aria-hidden', 'true'); $$('#tools button[data-panel]').forEach(b => b.classList.remove('on')); }
  $('#tools').addEventListener('click', e => { const b = e.target.closest('button[data-panel]'); if (b) openPanel(b.dataset.panel); });
  $('#drawerClose').addEventListener('click', closePanel);
  $('#viewTabs').addEventListener('click', e => { const b = e.target.closest('button[data-view]'); if (b) setView(b.dataset.view); });

  // ───────────────── Embutido na página ─────────────────
  if (EMBED) {
    $('#btnClose').hidden = false; $('#btnLayout').hidden = false;
    $('#btnClose').addEventListener('click', closeReader);
    let side = false;
    $('#btnLayout').addEventListener('click', () => { side = !side; parent.postMessage({ fai: 'layout', mode: side ? 'side' : 'full' }, '*'); });
  }

  // ───────────────── Eventos internos ─────────────────
  const listeners = {};
  const FAI = globalThis.FAI = {
    E, S, $, $$, EMBED, params, app, docEl, scrollEl, FONTS, THEMES, DEFAULT_PRESETS, DEFAULT_PREFS,
    toast, esc, tabCmd, download, slug, store, savePrefs, applyTypography, renderView, renderPalette, loadDoc, setView, setSegments, persist,
    addMark, removeMark, updateMark, rangeFrom, buildIndex, sanitize, previewCss, presetById, paintHighlights, setActive, normUrl,
    openPanel, closePanel, panels, hideFloat,
    on: (ev, fn) => (listeners[ev] ||= []).push(fn),
    emit: (ev, ...a) => (listeners[ev] || []).forEach(fn => { try { fn(...a); } catch (err) { console.error(err); } }),
    seek: t => {
      if (t == null) return;
      if (EMBED && S.doc?.video) return tabCmd({ type: 'VIDEO_SEEK', t, play: true });
      if (S.doc?.url && /youtube\.com/.test(S.doc.url)) window.open(`${normUrl(S.doc.url)}&t=${Math.floor(t)}s`, '_blank');
      else toast('Sem vídeo ligado a esta transcrição.');
    }
  };
  docEl.addEventListener('click', e => { const ts = e.target.closest('.ts'); if (ts) { e.preventDefault(); FAI.seek(+ts.dataset.t); } });

  // ───────────────── Arranque ─────────────────
  (async () => {
    const saved = await store.get('fai8:prefs');
    if (saved) { S.prefs = { ...DEFAULT_PREFS, ...saved, whisper: { ...DEFAULT_PREFS.whisper, ...(saved.whisper || {}) } }; if (!Array.isArray(S.prefs.presets) || !S.prefs.presets.length) S.prefs.presets = structuredClone(DEFAULT_PRESETS); }
    if (!globalThis.CSS?.highlights) toast('⚠️ Chrome antigo: atualize para ver as marcações (requer Chrome 105+).', 6000);
    applyTypography();
    FAI.emit('boot');
  })();
})();
