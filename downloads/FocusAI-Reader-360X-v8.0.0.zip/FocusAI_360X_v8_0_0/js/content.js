/* FocusAI 360X v8.0.0 — script de página: extração, vídeo/transcrição e sobreposição do leitor */
(() => {
  'use strict';
  const VERSION = '8.0.0';
  if (globalThis.__FAI8__?.version === VERSION) return;
  const E = globalThis.FAIEngine;
  const EXT_ORIGIN = new URL(chrome.runtime.getURL('')).origin;
  const state = { frame: null, layout: 'full', live: null, prevOverflow: '' };
  globalThis.__FAI8__ = { version: VERSION };

  const sleep = ms => new Promise(r => setTimeout(r, ms));
  const send = msg => chrome.runtime.sendMessage(msg);

  // ───────────────── Extração de conteúdo ─────────────────
  const JUNK = 'script,style,noscript,iframe,svg:not(figure svg),nav,footer,header,aside,form,button,input,select,textarea,[role="navigation"],[role="banner"],[aria-hidden="true"],.ad,.ads,[class*="advert" i],[id*="cookie" i],[class*="cookie" i]';

  function absolutize(root, base) {
    root.querySelectorAll('[src],[href],[srcset]').forEach(el => {
      for (const a of ['src', 'href']) {
        const v = el.getAttribute(a);
        if (v && !/^(data:|blob:|#|mailto:|javascript:)/i.test(v)) { try { el.setAttribute(a, new URL(v, base).href); } catch {} }
      }
      if (el.hasAttribute('srcset')) {
        const best = el.getAttribute('srcset').split(',').map(s => s.trim().split(/\s+/)[0]).filter(Boolean).pop();
        if (best && !el.getAttribute('src')) { try { el.setAttribute('src', new URL(best, base).href); } catch {} }
        el.removeAttribute('srcset');
      }
    });
    // imagens preguiçosas (data-src)
    root.querySelectorAll('img').forEach(img => {
      const lazy = img.getAttribute('data-src') || img.getAttribute('data-lazy-src') || img.getAttribute('data-original');
      if (lazy && (!img.getAttribute('src') || /^data:image\/(gif|svg)/.test(img.getAttribute('src')))) { try { img.setAttribute('src', new URL(lazy, base).href); } catch {} }
    });
  }

  function textLen(html) { const d = document.createElement('div'); d.innerHTML = html; return (d.textContent || '').replace(/\s+/g, ' ').trim().length; }

  function extractArticle() {
    let html = '', title = document.title, byline = '';
    try {
      const clone = document.cloneNode(true);
      absolutize(clone, location.href);
      const art = new Readability(clone, { charThreshold: 300, keepClasses: false }).parse();
      if (art?.content) { html = art.content; title = art.title || title; byline = art.byline || ''; }
    } catch (e) { console.warn('[FocusAI] Readability falhou', e); }
    const full = extractFull();
    // Chats de IA e páginas sem "artigo": se o Readability pegou pouco, usa a página limpa
    if (!html || textLen(html) < Math.min(1200, textLen(full.html) * 0.35)) return { html: full.html, title, byline, source: 'page' };
    return { html, title, byline, source: 'article' };
  }

  function extractFull() {
    const main = document.querySelector('main, [role="main"], article') || document.body;
    const clone = main.cloneNode(true);
    absolutize(clone, location.href);
    clone.querySelectorAll(JUNK).forEach(n => n.remove());
    return { html: clone.innerHTML, title: document.title, source: 'page' };
  }

  function extractSelection() {
    const sel = getSelection();
    if (!sel || sel.isCollapsed) return null;
    const box = document.createElement('div');
    for (let i = 0; i < sel.rangeCount; i++) box.appendChild(sel.getRangeAt(i).cloneContents());
    absolutize(box, location.href);
    box.querySelectorAll('script,style').forEach(n => n.remove());
    return { html: box.innerHTML, title: document.title, source: 'selection' };
  }

  function videoInfo() {
    const v = mainVideo();
    const host = location.hostname;
    const platform = /youtube\.com$/.test(host) ? 'youtube' : /drive\.google\.com$/.test(host) ? 'drive' : v ? 'html5' : '';
    return platform ? { platform, duration: v?.duration || 0 } : null;
  }

  function mainVideo() {
    return [...document.querySelectorAll('video')].sort((a, b) => (b.clientWidth * b.clientHeight) - (a.clientWidth * a.clientHeight))[0] || null;
  }

  // ───────────────── Transcrição: cascata de extração ─────────────────
  async function extractTranscript() {
    const tries = [];
    const attempt = async (name, fn) => {
      try { const segs = await fn(); if (segs?.length) return { ok: true, segments: segs, source: name }; tries.push(`${name}: vazio`); }
      catch (e) { tries.push(`${name}: ${e.message || e}`); }
      return null;
    };
    const isYT = /youtube\.com$/.test(location.hostname);
    const result =
      (isYT && await attempt('YouTube (faixa de legenda)', youtubeTrack)) ||
      (isYT && await attempt('YouTube (painel de transcrição)', youtubePanel)) ||
      await attempt('Faixas do vídeo (VTT/TextTrack)', textTracks) ||
      await attempt('Painel com horários (Drive e outros)', timestampPanel);
    if (result) return { ...result, title: document.title.replace(/ - YouTube$/, ''), url: location.href };
    return { ok: false, error: 'Nenhuma legenda/transcrição disponível nesta página.', tries };
  }

  async function youtubeTrack() {
    const vid = new URL(location.href).searchParams.get('v');
    if (!vid) throw new Error('não é página de vídeo');
    const html = await fetch(`https://www.youtube.com/watch?v=${vid}`, { credentials: 'include' }).then(r => r.text());
    const m = html.match(/"captionTracks":(\[.*?\])(,"audioTracks"|,"translationLanguages"|\])/);
    if (!m) throw new Error('sem faixas de legenda');
    const tracks = JSON.parse(m[1]);
    const score = t => (/^pt/.test(t.languageCode) ? 4 : /^en/.test(t.languageCode) ? 2 : 0) + (t.kind === 'asr' ? 0 : 1);
    const track = tracks.sort((a, b) => score(b) - score(a))[0];
    const url = track.baseUrl.replace(/\\u0026/g, '&') + '&fmt=json3';
    const res = await send({ type: 'FAI_FETCH_TEXT', url });
    if (!res?.ok || !res.text?.trim()) throw new Error('faixa protegida/vazia');
    return E.parseYTJson3(res.text);
  }

  async function youtubePanel() {
    const segSel = 'ytd-transcript-segment-renderer, transcript-segment-view-model';
    if (!document.querySelector(segSel)) {
      document.querySelector('#description-inline-expander #expand, tp-yt-paper-button#expand, #expand')?.click();
      await sleep(400);
      const btn = document.querySelector('ytd-video-description-transcript-section-renderer button') ||
        [...document.querySelectorAll('button')].find(b => /transcri/i.test(b.getAttribute('aria-label') || b.textContent || ''));
      if (!btn) throw new Error('botão "Mostrar transcrição" não encontrado');
      btn.click();
      for (let i = 0; i < 30 && !document.querySelector(segSel); i++) await sleep(250);
    }
    const segs = [...document.querySelectorAll(segSel)].map(el => {
      const lines = (el.innerText || '').split('\n').map(s => s.trim()).filter(Boolean);
      const ti = lines.findIndex(l => /^(\d{1,2}:)?\d{1,2}:\d{2}$/.test(l));
      if (ti < 0) return null;
      return { start: E.toSec(lines[ti]), end: E.toSec(lines[ti]) + 4, text: lines.filter((_, i) => i !== ti && !/^\d+ (segundos?|minutos?|seconds?|minutes?)/i.test(lines[i])).join(' ') };
    }).filter(Boolean);
    for (let i = 0; i < segs.length - 1; i++) segs[i].end = Math.max(segs[i].start + 0.5, segs[i + 1].start);
    return E.merge(segs, { join: false });
  }

  async function textTracks() {
    const v = mainVideo();
    let segs = [];
    for (const tr of document.querySelectorAll('video track[src], track[src]')) {
      try { const t = await fetch(tr.src).then(r => r.text()); segs = E.parseAny(t, tr.src).segments || []; if (segs.length) return segs; } catch {}
    }
    if (v?.textTracks?.length) {
      for (const t of v.textTracks) if (t.mode === 'disabled') t.mode = 'hidden';
      await sleep(900);
      for (const t of v.textTracks) {
        const cues = [...(t.cues || [])];
        if (cues.length) return E.merge(cues.map(c => ({ start: c.startTime, end: c.endTime, text: c.text })));
      }
    }
    return [];
  }

  /** Painéis virtualizados com horários (ex.: Transcrição do Google Drive). */
  async function timestampPanel() {
    const TS = /^\s*((?:\d{1,2}:)?\d{1,2}:\d{2})\s*\n+\s*(\S[\s\S]*)$/;
    const collect = acc => {
      const all = [...document.querySelectorAll('div, li, p, span, button, [role="listitem"], [role="button"]')];
      for (const el of all) {
        if (el.childElementCount > 8) continue;
        const txt = el.innerText || '';
        if (txt.length > 900 || !TS.test(txt)) continue;
        if ([...el.children].some(c => TS.test(c.innerText || ''))) continue;
        const m = txt.match(TS);
        const key = `${m[1]}|${m[2].slice(0, 40)}`;
        if (!acc.has(key)) acc.set(key, { start: E.toSec(m[1]), end: E.toSec(m[1]) + 4, text: m[2].replace(/\s+/g, ' ') });
      }
      return all;
    };
    const acc = new Map();
    collect(acc);
    if (!acc.size) throw new Error('nenhum painel com horários aberto');
    // rola o contêiner para carregar itens virtualizados
    const firstKey = acc.keys().next().value?.split('|')[0];
    const anchor = [...document.querySelectorAll('div,span')].find(el => (el.innerText || '').trim().startsWith(firstKey));
    let box = anchor; while (box && !(box.scrollHeight > box.clientHeight + 40 && /(auto|scroll)/.test(getComputedStyle(box).overflowY))) box = box.parentElement;
    if (box) {
      const original = box.scrollTop; box.scrollTop = 0; await sleep(250);
      for (let i = 0; i < 500; i++) {
        collect(acc);
        if (box.scrollTop + box.clientHeight >= box.scrollHeight - 4) break;
        box.scrollTop += Math.max(120, box.clientHeight * 0.8); await sleep(180);
      }
      collect(acc); box.scrollTop = original;
    }
    const segs = [...acc.values()].sort((a, b) => a.start - b.start);
    for (let i = 0; i < segs.length - 1; i++) segs[i].end = Math.max(segs[i].start + 0.5, segs[i + 1].start);
    return E.merge(segs, { join: false });
  }

  // ───────── Captura de legendas ao vivo ─────────
  const CAPTION_SEL = '.ytp-caption-segment, .captions-text, .vjs-text-track-display, .plyr__caption, .shaka-text-container, [class*="caption-window" i], [class*="subtitle" i] span';
  function liveStart() {
    if (state.live) return { ok: true, running: true };
    const v = mainVideo();
    const live = state.live = { segs: [], last: '', timer: 0 };
    if (v) for (const t of v.textTracks || []) if (t.mode === 'disabled') t.mode = 'hidden';
    live.timer = setInterval(() => {
      let text = [...document.querySelectorAll(CAPTION_SEL)].map(n => n.innerText || n.textContent).join(' ').replace(/\s+/g, ' ').trim();
      if (!text && v) for (const t of v.textTracks || []) for (const c of t.activeCues || []) text += ' ' + c.text;
      text = text.trim();
      const now = v ? v.currentTime : performance.now() / 1000;
      if (text && text !== live.last) { live.segs.push({ start: now, end: now + 2, text }); live.last = text; }
      else if (text && live.segs.length) live.segs[live.segs.length - 1].end = now;
    }, 350);
    return { ok: true, running: true };
  }
  function liveStop() {
    const live = state.live; if (!live) return { ok: false, error: 'Captura não iniciada.' };
    clearInterval(live.timer); state.live = null;
    return { ok: true, segments: E.merge(live.segs, { maxGap: 1.5 }), source: 'Legendas ao vivo', title: document.title, url: location.href };
  }

  // ───────────────── Sobreposição do leitor (iframe da extensão) ─────────────────
  async function open(mode) {
    let content;
    if (mode === 'selection') content = extractSelection() || extractArticle();
    else content = extractArticle();
    const payload = { kind: 'page', url: location.href, title: content.title, byline: content.byline || '', html: content.html, source: content.source, video: videoInfo(), selectionAvailable: !!extractSelection() };
    const { token } = await send({ type: 'FAI_STASH', payload });
    const frame = document.createElement('iframe');
    frame.src = chrome.runtime.getURL(`reader.html?embed=1&t=${token}`);
    frame.setAttribute('allow', 'clipboard-write');
    frame.setAttribute('aria-label', 'FocusAI leitor limpo');
    frame.style.cssText = 'all:initial;position:fixed;z-index:2147483647;border:0;background:#0E1116;box-shadow:0 0 0 1px rgba(201,162,39,.35),0 20px 80px rgba(0,0,0,.55);transition:all .18s ease;';
    document.documentElement.appendChild(frame);
    state.frame = frame;
    setLayout(payload.video && mode !== 'article' && /youtube|drive/.test(payload.video.platform) ? 'side' : 'full');
    frame.focus();
  }

  function setLayout(mode) {
    const f = state.frame; if (!f) return;
    state.layout = mode;
    const full = mode === 'full';
    Object.assign(f.style, full
      ? { inset: '0', top: '0', left: '0', width: '100vw', height: '100vh', borderRadius: '0' }
      : { top: '0', left: 'auto', right: '0', width: 'min(46vw, 760px)', height: '100vh', borderRadius: '14px 0 0 14px' });
    if (full) { state.prevOverflow = document.documentElement.style.overflow; document.documentElement.style.overflow = 'hidden'; }
    else document.documentElement.style.overflow = state.prevOverflow || '';
  }

  function close() {
    state.frame?.remove(); state.frame = null;
    document.documentElement.style.overflow = state.prevOverflow || '';
  }

  window.addEventListener('message', ev => {
    if (ev.origin !== EXT_ORIGIN || !state.frame || ev.source !== state.frame.contentWindow) return;
    const d = ev.data || {};
    if (d.fai === 'close') close();
    if (d.fai === 'layout') setLayout(d.mode);
  });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && state.frame && document.activeElement !== state.frame) close(); }, true);

  // ───────────────── Mensagens ─────────────────
  chrome.runtime.onMessage.addListener((msg, _s, reply) => {
    const v = () => mainVideo();
    const done = p => { Promise.resolve(p).then(reply, e => reply({ ok: false, error: String(e?.message || e) })); return true; };
    switch (msg?.type) {
      case 'FAI_PING': reply({ version: VERSION }); return false;
      case 'FAI_ACTIVATE':
        if (state.frame && msg.mode === 'toggle') { close(); reply({ ok: true, closed: true }); return false; }
        if (state.frame) close();
        return done(open(msg.mode === 'toggle' ? 'auto' : msg.mode).then(() => ({ ok: true })));
      case 'TX_EXTRACT': return done(extractTranscript());
      case 'TX_LIVE_START': reply(liveStart()); return false;
      case 'TX_LIVE_STOP': reply(liveStop()); return false;
      case 'TX_LIVE_STATUS': reply({ ok: true, running: !!state.live, count: state.live?.segs.length || 0, time: v()?.currentTime || 0 }); return false;
      case 'VIDEO_SEEK': { const el = v(); if (el) { el.currentTime = Math.max(0, +msg.t || 0); if (msg.play) el.play().catch(() => {}); } reply({ ok: !!el }); return false; }
      case 'VIDEO_STATE': { const el = v(); reply({ ok: !!el, time: el?.currentTime || 0, paused: el?.paused ?? true, duration: el?.duration || 0 }); return false; }
      case 'VIDEO_TOGGLE': { const el = v(); if (el) el.paused ? el.play().catch(() => {}) : el.pause(); reply({ ok: !!el }); return false; }
      case 'GET_CONTENT': reply({ ok: true, ...(msg.mode === 'full' ? extractFull() : msg.mode === 'selection' ? (extractSelection() || { html: '' }) : extractArticle()) }); return false;
      case 'LAYOUT': setLayout(msg.mode); reply({ ok: true }); return false;
      case 'CLOSE': close(); reply({ ok: true }); return false;
      default: return false;
    }
  });
})();
