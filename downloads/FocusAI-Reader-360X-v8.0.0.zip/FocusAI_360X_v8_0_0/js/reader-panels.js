/* FocusAI 360X v8.0.0 — painéis, transcrição, ponte Nexus, exportação, biblioteca e arquivos */
(() => {
  'use strict';
  const F = globalThis.FAI, E = F.E, S = F.S, { $, $$, esc, toast } = F;

  const field = (label, key, min, max, step, fmt = v => v) => `<label class="field">${label}<input type="range" data-pref="${key}" min="${min}" max="${max}" step="${step}" value="${S.prefs[key]}"><output>${fmt(S.prefs[key])}</output></label>`;
  const sw = (label, key, hint = '') => `<label class="switch"><span>${label}${hint ? `<br><small style="color:var(--ui-dim)">${hint}</small>` : ''}</span><input type="checkbox" data-pref="${key}" ${S.prefs[key] ? 'checked' : ''}></label>`;
  const FMT = { size: v => `${v}px`, lh: v => (+v).toFixed(2), ls: v => (+v).toFixed(2), ws: v => (+v).toFixed(2), measure: v => `${v}ch`, pgap: v => (+v).toFixed(2), wpm: v => v };
  function bindPrefs(body, rerender = []) {
    body.addEventListener('input', e => {
      const el = e.target.closest('[data-pref]'); if (!el) return;
      const k = el.dataset.pref; S.prefs[k] = el.type === 'checkbox' ? el.checked : el.type === 'range' ? +el.value : el.value;
      if (el.type === 'range') el.nextElementSibling.textContent = (FMT[k] || (v => v))(el.value);
      F.savePrefs(); rerender.includes(k) ? F.renderView() : F.applyTypography();
    });
  }

  // ═════════ Índice ═════════
  F.panels.toc = {
    title: '☰ Índice', render(body) {
      const hs = $$('#doc h1, #doc h2, #doc h3, #doc h4').filter(h => h.textContent.trim());
      if (!hs.length) { body.innerHTML = '<p class="hint">Este texto não tem títulos internos.</p>'; return; }
      body.innerHTML = `<div class="toc">${hs.map((h, i) => `<a href="#" data-i="${i}" class="l${h.tagName[1]}">${esc(h.textContent.trim().slice(0, 120))}</a>`).join('')}</div>`;
      body.addEventListener('click', e => { const a = e.target.closest('a[data-i]'); if (!a) return; e.preventDefault(); hs[+a.dataset.i].scrollIntoView({ behavior: 'smooth', block: 'start' }); });
    }
  };

  // ═════════ Leitura (tipografia) ═════════
  F.panels.typo = {
    title: 'Aa Leitura e fonte', render(body) {
      const P = S.prefs;
      body.innerHTML = `
        <h3>Fonte</h3>
        <div class="chips" data-group="font">${Object.entries(F.FONTS).map(([k, f]) => `<button class="chip ${f.cls} ${P.font === k ? 'on' : ''}" data-v="${k}">${f.label}</button>`).join('')}</div>
        <p class="hint">OpenDyslexic tem a base das letras mais pesada, para elas não "girarem". Lexend e Atkinson são alternativas mais leves.</p>
        <h3>Fundo</h3>
        <div class="chips" data-group="theme">${Object.entries(F.THEMES).map(([k, v]) => `<button class="chip ${P.theme === k ? 'on' : ''}" data-v="${k}">${v}</button>`).join('')}</div>
        <h3>Tamanho e espaçamento</h3>
        ${field('Tamanho', 'size', 14, 36, 1, FMT.size)}
        ${field('Entre linhas', 'lh', 1.3, 2.6, 0.05, FMT.lh)}
        ${field('Entre letras', 'ls', 0, 0.2, 0.01, FMT.ls)}
        ${field('Entre palavras', 'ws', 0, 0.6, 0.02, FMT.ws)}
        ${field('Largura', 'measure', 40, 100, 2, FMT.measure)}
        ${field('Entre parágrafos', 'pgap', 0.5, 2.5, 0.05, FMT.pgap)}
        <h3>Ajudas de foco</h3>
        ${sw('🔦 Holofote no parágrafo', 'spotlight', 'Escurece o resto · J/K anda entre parágrafos')}
        ${sw('📏 Régua de leitura', 'ruler', 'Faixa que acompanha o mouse')}
        ${sw('⚡ Leitura biônica', 'bionic', 'Início das palavras em negrito')}
        ${sw('✂️ Quebrar parágrafos longos', 'chunk', 'Blocos de até ~48 palavras')}
        ${sw('🔢 Numerar parágrafos', 'numbered')}
        ${sw('🎨 Mostrar paleta lateral', 'palette')}
        ${field('Velocidade (palavras/min)', 'wpm', 100, 400, 10, FMT.wpm)}
        <div class="grid2"><button class="btn" data-act="preset-tdah">🧠 Perfil TDAH</button><button class="btn" data-act="preset-dis">🔤 Perfil dislexia</button></div>
        <button class="btn wide" data-act="reset">↺ Restaurar padrão</button>`;
      body.addEventListener('click', e => {
        const chip = e.target.closest('.chips[data-group] .chip');
        if (chip) { const g = chip.parentElement.dataset.group; S.prefs[g] = chip.dataset.v; $$('.chip', chip.parentElement).forEach(c => c.classList.toggle('on', c === chip)); F.savePrefs(); F.applyTypography(); return; }
        const act = e.target.closest('[data-act]')?.dataset.act;
        const profiles = {
          'preset-tdah': { font: 'lx', size: 20, lh: 1.8, ls: 0.01, ws: 0.1, measure: 58, pgap: 1.3, spotlight: true, chunk: true, bionic: true, ruler: false },
          'preset-dis': { font: 'od', size: 21, lh: 2.0, ls: 0.05, ws: 0.22, measure: 60, pgap: 1.3, theme: 'pergaminho', bionic: false, chunk: true, ruler: true },
          reset: { ...F.DEFAULT_PREFS, presets: S.prefs.presets, activePreset: S.prefs.activePreset, nexusId: S.prefs.nexusId, whisper: S.prefs.whisper }
        };
        if (profiles[act]) { Object.assign(S.prefs, profiles[act]); F.savePrefs(); F.renderView(); F.openPanel('typo', true); toast(act === 'reset' ? '↺ Padrão restaurado' : '✅ Perfil aplicado — ajuste à vontade'); }
      });
      bindPrefs(body, ['bionic', 'chunk']);
    }
  };

  // ═════════ Marcações + editor de estilos ═════════
  const KINDS = { hl: 'Marca-texto', ul: 'Sublinhado', hlul: 'Marca-texto + sublinhado', tx: 'Texto colorido' };
  const LINES = { solid: 'Reto', double: 'Duplo', wavy: 'Ondulado', dotted: 'Pontilhado', dashed: 'Tracejado' };
  F.panels.marks = {
    title: '🖍 Marcações', render(body) {
      const draw = () => {
        const list = S.marks.slice().sort((a, b) => a.pos - b.pos);
        body.innerHTML = `
          <p class="hint">Selecione o texto e escolha a cor. <b>Atalhos:</b> <kbd>1</kbd>–<kbd>9</kbd> aplicam o estilo, <kbd>P</kbd> trava a caneta, <kbd>E</kbd> borracha. Clique numa marcação para anotar.</p>
          <h3>Neste texto (${list.length})</h3>
          <div class="list">${list.length ? list.map(m => { const p = F.presetById(m.presetId) || m.style; return `<div class="item" data-id="${m.id}"><span class="dot" style="${F.previewCss(p)}"></span><div><div class="t">${esc(m.quote.slice(0, 180))}${m.quote.length > 180 ? '…' : ''}</div>${m.note ? `<div class="n">📝 ${esc(m.note)}</div>` : ''}</div><button class="x" data-del="${m.id}" title="Apagar">✕</button></div>`; }).join('') : '<p class="hint">Nenhuma marcação ainda.</p>'}</div>
          ${list.length ? '<div class="grid2"><button class="btn" data-act="md">⬇ Marcações (.md)</button><button class="btn danger" data-act="clear">🗑 Apagar todas</button></div>' : ''}
          <h3>Seus estilos de caneta</h3>
          <div class="list" id="presetList">${S.prefs.presets.map((p, i) => presetEditor(p, i)).join('')}</div>
          <div class="grid2"><button class="btn" data-act="add">＋ Novo estilo</button><button class="btn" data-act="defaults">↺ Estilos padrão</button></div>`;
      };
      const presetEditor = (p, i) => `<div class="preset" data-pid="${p.id}">
          <div class="top"><b style="color:var(--gold-soft)">${i + 1}</b><span class="prev" style="${F.previewCss(p)}">${esc(p.name)}</span><input type="color" data-k="color" value="${p.color}" title="Cor"><button class="x" data-rm="${p.id}" title="Remover estilo" style="border:0;background:transparent;color:var(--ui-dim)">✕</button></div>
          <div class="opts">
            <input type="text" data-k="name" value="${esc(p.name)}" placeholder="Nome">
            <select data-k="kind">${Object.entries(KINDS).map(([k, v]) => `<option value="${k}" ${p.kind === k ? 'selected' : ''}>${v}</option>`).join('')}</select>
            <select data-k="line" ${p.kind === 'hl' || p.kind === 'tx' ? 'disabled' : ''}>${Object.entries(LINES).map(([k, v]) => `<option value="${k}" ${p.line === k ? 'selected' : ''}>Linha: ${v}</option>`).join('')}</select>
            <label class="field" style="grid-template-columns:auto 1fr;gap:6px">${p.kind === 'hl' || p.kind === 'hlul' ? 'Opac.' : 'Esp.'}<input type="range" data-k="${p.kind === 'hl' || p.kind === 'hlul' ? 'alpha' : 'thick'}" min="${p.kind === 'hl' || p.kind === 'hlul' ? 0.15 : 1}" max="${p.kind === 'hl' || p.kind === 'hlul' ? 0.9 : 6}" step="${p.kind === 'hl' || p.kind === 'hlul' ? 0.05 : 1}" value="${p.kind === 'hl' || p.kind === 'hlul' ? p.alpha : p.thick}"></label>
          </div></div>`;
      draw();
      const refresh = () => { F.paintHighlights(); F.renderPalette(); F.savePrefs(); };
      body.addEventListener('input', e => {
        const box = e.target.closest('.preset'); if (!box) return;
        const p = S.prefs.presets.find(x => x.id === box.dataset.pid); const k = e.target.dataset.k; if (!p || !k) return;
        p[k] = e.target.type === 'range' ? +e.target.value : e.target.value;
        if (k === 'kind' && p.kind === 'hlul' && !p.ucolor) p.ucolor = p.color;
        box.querySelector('.prev').setAttribute('style', F.previewCss(p)); if (k === 'name') box.querySelector('.prev').textContent = p.name;
        refresh(); if (k === 'kind') { const i = S.prefs.presets.indexOf(p); box.outerHTML = presetEditor(p, i); }
      });
      body.addEventListener('click', e => {
        const item = e.target.closest('.item[data-id]'); const del = e.target.closest('[data-del]'); const rm = e.target.closest('[data-rm]'); const act = e.target.closest('[data-act]')?.dataset.act;
        if (del) { F.removeMark(del.dataset.del); draw(); return; }
        if (item) { const m = S.marks.find(x => x.id === item.dataset.id); const r = m && F.S.ranges.get(m.id); r?.startContainer?.parentElement?.scrollIntoView({ behavior: 'smooth', block: 'center' }); return; }
        if (rm) { if (S.prefs.presets.length <= 1) return toast('Mantenha ao menos um estilo'); S.prefs.presets = S.prefs.presets.filter(p => p.id !== rm.dataset.rm); if (S.prefs.activePreset === rm.dataset.rm) S.prefs.activePreset = S.prefs.presets[0].id; refresh(); draw(); return; }
        if (act === 'add') { if (S.prefs.presets.length >= 9) return toast('Máximo de 9 estilos (atalhos 1–9)'); S.prefs.presets.push({ id: `p${Date.now().toString(36)}`, name: 'Novo estilo', kind: 'hl', color: '#B197FC', alpha: 0.45, line: 'solid', thick: 2 }); refresh(); draw(); }
        if (act === 'defaults') { S.prefs.presets = structuredClone(F.DEFAULT_PRESETS); S.prefs.activePreset = 'p1'; refresh(); draw(); }
        if (act === 'clear' && confirm('Apagar todas as marcações deste texto?')) { S.marks.splice(0); F.S.ranges.clear(); F.paintHighlights(); F.persist(true); draw(); }
        if (act === 'md') F.download(`${F.slug(S.doc.title)}_marcacoes.md`, marksMarkdown());
      });
      F.on('marks', () => { if ($('#drawer').classList.contains('open') && $('#drawerTitle').textContent.startsWith('🖍')) draw(); });
    }
  };

  function marksMarkdown() {
    const lines = [`# 🖍 Marcações — ${S.doc.title}`, '', S.doc.url ? `Fonte: ${S.doc.url}` : '', `_FocusAI 360X · ${new Date().toLocaleString('pt-BR')}_`, ''];
    const groups = {};
    for (const m of S.marks.slice().sort((a, b) => a.pos - b.pos)) (groups[(F.presetById(m.presetId) || m.style).name] ||= []).push(m);
    for (const [name, ms] of Object.entries(groups)) {
      lines.push(`## ${name}`, '');
      for (const m of ms) { lines.push(`> ${m.t != null ? `**[${E.fmt(m.t)}]** ` : ''}${m.quote.replace(/\n+/g, ' ')}`); if (m.note) lines.push('', `📝 ${m.note}`); lines.push(''); }
    }
    return lines.join('\n');
  }

  // ═════════ Transcrição ═════════
  let liveTimer = 0, followTimer = 0, recording = false, lastTx = ['Pronto.', ''];
  F.panels.tx = {
    title: '🎙 Transcrição', render(body) {
      const hasVideo = F.EMBED && !!S.doc?.video;
      const segs = S.doc?.segments || [];
      const W = S.prefs.whisper;
      body.innerHTML = `
        ${hasVideo ? `
        <h3>1 · Extrair do vídeo</h3>
        <button class="btn primary wide" data-act="extract">⚡ Extrair transcrição pronta</button>
        <p class="hint">Tenta, nesta ordem: faixa de legenda do YouTube → painel de transcrição → faixas VTT do vídeo → painel com horários (Google Drive). No Drive, abra antes o painel <b>Transcrição</b> do próprio Drive.</p>
        <h3>2 · Sem legenda pronta?</h3>
        <div class="grid2"><button class="btn" data-act="live">🛰 Legendas ao vivo</button><button class="btn" data-act="whisper">🧠 Whisper local</button></div>
        <div id="txStatus" class="status ${lastTx[1]}">${lastTx[0]}</div>
        <details ${recording ? 'open' : ''}><summary style="cursor:pointer;color:var(--ui-dim);font-size:13px">⚙️ Whisper local (áudio da aba)</summary>
          <div style="display:grid;gap:8px;margin-top:8px">
            <select data-w="model">${['tiny', 'base', 'small', 'medium', 'large-v3'].map(m => `<option ${W.model === m ? 'selected' : ''}>${m}</option>`).join('')}</select>
            <select data-w="language">${[['pt', 'Português'], ['en', 'Inglês'], ['es', 'Espanhol'], ['auto', 'Detectar']].map(([v, l]) => `<option value="${v}" ${W.language === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
            <input type="text" data-w="endpoint" value="${esc(W.endpoint)}">
            <div class="grid3"><button class="btn" data-act="w-test">🔌 Testar</button><button class="btn" data-act="w-stop">⏹ Finalizar</button><button class="btn danger" data-act="w-cancel">✕</button></div>
            <p class="hint">Rode antes <code>companion/INICIAR-WHISPER-MAC.command</code>. A gravação é em tempo real (vídeo de 1 h = 1 h tocando).</p>
          </div></details>` : `<p class="hint">${F.EMBED ? 'Nenhum vídeo nesta página.' : 'Abra o leitor pela aba do vídeo (clique no ícone do FocusAI) para extrair transcrições.'} Você também pode importar um arquivo.</p>`}
        <h3>${hasVideo ? '3 · ' : ''}Importar / converter arquivo</h3>
        <button class="btn wide" data-act="import">📂 Abrir SRT, VTT, SBV, ASS, TTML, JSON, TXT ou backup do Nexus</button>
        ${segs.length ? `
        <h3>Transcrição atual · ${segs.length} trechos · ${E.fmt(segs[segs.length - 1].end || segs[segs.length - 1].start)}</h3>
        ${hasVideo ? `<label class="switch"><span>🎯 Seguir o vídeo<br><small style="color:var(--ui-dim)">Destaca e rola até o trecho que está tocando</small></span><input type="checkbox" data-pref="follow" ${S.prefs.follow ? 'checked' : ''}></label>` : ''}
        <label class="field">Capítulos de<input type="range" data-pref="chapterMin" min="1" max="20" step="1" value="${S.prefs.chapterMin}"><output>${S.prefs.chapterMin} min</output></label>
        <div class="grid3"><button class="btn" data-x="txt">TXT</button><button class="btn" data-x="md">Markdown</button><button class="btn" data-x="srt">SRT</button><button class="btn" data-x="vtt">VTT</button><button class="btn" data-x="json">JSON</button><button class="btn" data-x="nexus">Nexus</button></div>
        <div class="grid2"><button class="btn" data-act="copy">📋 Copiar texto</button><button class="btn" data-act="send-nexus">🔗 Enviar ao Nexus</button></div>
        <button class="btn danger wide" data-act="tx-clear">Remover transcrição deste documento</button>` : ''}`;
      const status = (msg, cls = '') => { lastTx = [msg, cls]; const s = $('#txStatus'); if (s) { s.className = `status ${cls}`; s.innerHTML = msg; } };
      body.addEventListener('input', e => {
        const w = e.target.dataset.w; if (w) { S.prefs.whisper[w] = e.target.value; F.savePrefs(); return; }
        const k = e.target.dataset.pref; if (!k) return;
        S.prefs[k] = e.target.type === 'checkbox' ? e.target.checked : +e.target.value; F.savePrefs();
        if (k === 'chapterMin') { e.target.nextElementSibling.textContent = `${e.target.value} min`; if (S.view === 'transcript') F.renderView(); }
        if (k === 'follow') startFollow();
      });
      body.addEventListener('click', async e => {
        const b = e.target.closest('button'); if (!b) return;
        const act = b.dataset.act, x = b.dataset.x;
        if (x) return exportTranscript(x);
        if (act === 'extract') {
          b.disabled = true; status('⏳ Procurando legenda/transcrição…', 'warn');
          const r = await F.tabCmd({ type: 'TX_EXTRACT' }); b.disabled = false;
          if (r?.ok) { status(`✅ ${r.segments.length} trechos · fonte: ${esc(r.source)}`, 'ok'); F.setSegments(r.segments, r); toast('🎙 Transcrição pronta'); F.openPanel('tx', true); startFollow(); }
          else status(`⚠️ ${esc(r?.error || 'Falhou')}${r?.tries ? `<br><small>${r.tries.map(esc).join('<br>')}</small>` : ''}<br>➡️ Tente <b>Legendas ao vivo</b> (com a legenda ligada no player) ou <b>Whisper local</b>.`, 'err');
        }
        if (act === 'live') {
          const st = await F.tabCmd({ type: 'TX_LIVE_STATUS' });
          if (!st?.running) {
            const r = await F.tabCmd({ type: 'TX_LIVE_START' });
            if (!r?.ok) return status(`⚠️ ${esc(r?.error)}`, 'err');
            b.textContent = '⏹ Parar captura'; status('🛰 Capturando… ligue a legenda (CC) no player e deixe o vídeo tocar.', 'warn');
            clearInterval(liveTimer); liveTimer = setInterval(async () => { const s = await F.tabCmd({ type: 'TX_LIVE_STATUS' }); if (s?.running) status(`🛰 Capturando · ${s.count} falas · ${E.fmt(s.time)}`, 'warn'); }, 1500);
          } else {
            clearInterval(liveTimer); const r = await F.tabCmd({ type: 'TX_LIVE_STOP' }); b.textContent = '🛰 Legendas ao vivo';
            if (r?.ok && r.segments.length) { F.setSegments(r.segments, r); toast(`✅ ${r.segments.length} trechos capturados`); F.openPanel('tx', true); }
            else status('⚠️ Nenhuma legenda foi vista na tela. Ligue o CC do player.', 'err');
          }
        }
        if (act === 'whisper' || act === 'w-test') {
          status('🔌 Testando Whisper local…', 'warn');
          const h = await chrome.runtime.sendMessage({ type: 'FAI_WHISPER_HEALTH', endpoint: S.prefs.whisper.endpoint });
          if (!h?.ok) return status(`⚠️ ${esc(h?.error || 'Whisper local não respondeu')}`, 'err');
          if (act === 'w-test') return status(`✅ Whisper local online · modelo padrão ${esc(h.data?.default_model || '')}`, 'ok');
          if (!confirm('Gravar o áudio desta aba para o Whisper local?\n\nDeixe o vídeo tocando até o fim e depois clique em ⏹ Finalizar.')) return;
          await F.tabCmd({ type: 'VIDEO_SEEK', t: 0, play: true });
          const r = await chrome.runtime.sendMessage({ type: 'FAI_AUDIO_START', ...S.prefs.whisper });
          if (!r?.ok) return status(`⚠️ ${esc(r?.error)}`, 'err');
          recording = true; status('🔴 Gravando o áudio da aba… clique ⏹ Finalizar quando o vídeo acabar.', 'warn');
        }
        if (act === 'w-stop') { const r = await chrome.runtime.sendMessage({ type: 'FAI_AUDIO_STOP' }); status(r?.ok === false ? `⚠️ ${esc(r.error)}` : '⏳ Enviando ao Whisper… isso pode levar alguns minutos.', r?.ok === false ? 'err' : 'warn'); }
        if (act === 'w-cancel') { await chrome.runtime.sendMessage({ type: 'FAI_AUDIO_CANCEL' }); recording = false; status('Gravação cancelada.'); }
        if (act === 'import') pickFile();
        if (act === 'copy') navigator.clipboard.writeText(E.toTXT(S.doc.segments)).then(() => toast('📋 Transcrição copiada'));
        if (act === 'send-nexus') sendToNexus();
        if (act === 'tx-clear' && confirm('Remover a transcrição deste documento?')) { S.doc.segments = null; if (S.record) delete S.record.segments; F.persist(true); F.setView('article'); F.openPanel('tx', true); }
      });
    }
  };

  function exportTranscript(fmt) {
    const segs = S.doc?.segments; if (!segs?.length) return;
    const meta = { title: S.doc.title, url: S.doc.url, chapterMinutes: S.prefs.chapterMin };
    const base = F.slug(S.doc.title);
    const out = {
      txt: [E.toTXT(segs), 'txt'], md: [E.toMD(segs, meta), 'md'], srt: [E.toSRT(segs), 'srt'], vtt: [E.toVTT(segs), 'vtt'], json: [E.toJSON(segs, meta), 'json'],
      nexus: [E.toNexusBackup([E.toNexusCapture({ ...meta, segments: segs, marks: S.view === 'transcript' ? S.marks : [] })]), 'nexus.json']
    }[fmt];
    F.download(`${base}.${out[1]}`, out[0], fmt === 'json' || fmt === 'nexus' ? 'application/json' : 'text/plain;charset=utf-8');
    toast(`⬇ ${out[1].toUpperCase()} baixado`);
  }

  // seguir o vídeo (karaokê de parágrafo)
  function startFollow() {
    clearInterval(followTimer);
    if (!F.EMBED || !S.doc?.video || !S.prefs.follow) { $$('.tx-p.now').forEach(p => p.classList.remove('now')); return; }
    let last = null;
    followTimer = setInterval(async () => {
      if (S.view !== 'transcript' || document.hidden) return;
      const st = await F.tabCmd({ type: 'VIDEO_STATE' }); if (!st?.ok || st.paused) return;
      const ps = $$('.tx-p'); const cur = ps.findLast?.(p => +p.dataset.start <= st.time + 0.3) || ps.filter(p => +p.dataset.start <= st.time + 0.3).pop();
      if (cur && cur !== last) { last?.classList.remove('now'); cur.classList.add('now'); last = cur; if (!getSelection().toString()) cur.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
    }, 1000);
  }
  F.on('render', () => { if (S.view === 'transcript') startFollow(); });

  chrome.runtime.onMessage.addListener(msg => {
    if (msg?.type === 'FAI_AUDIO_STATUS' && recording) {
      const s = $('#txStatus'); const map = { recording: `🔴 Gravando · ${E.fmt(msg.elapsed || 0)}`, uploading: '⏳ Transcrevendo no Whisper local…', error: `⚠️ ${esc(msg.message || 'Erro')}` };
      if (s) { s.className = `status ${msg.status === 'error' ? 'err' : 'warn'}`; s.innerHTML = map[msg.status] || esc(msg.message || ''); }
      if (msg.status === 'error') recording = false;
    }
    if (msg?.type === 'FAI_AUDIO_RESULT' && recording) {
      recording = false;
      const segs = E.merge(msg.result?.segments || []);
      if (segs.length) { F.setSegments(segs, {}); toast(`✅ Whisper: ${segs.length} trechos`); F.openPanel('tx', true); }
    }
  });

  // ═════════ Nexus Capture ═════════
  function currentCapture() {
    const d = S.doc; if (!d) return null;
    if (S.view === 'transcript' && d.segments?.length) return E.toNexusCapture({ title: d.title, url: d.url, segments: d.segments, marks: S.marks });
    return E.toNexusCapture({ title: d.title, url: d.url, html: d.html, text: F.docEl.innerText, marks: S.marks });
  }
  async function sendToNexus() {
    const cap = currentCapture(); if (!cap) return;
    const r = await chrome.runtime.sendMessage({ type: 'FAI_NEXUS_SEND', capture: cap });
    if (r?.ok) { toast('✅ Enviado ao Nexus Capture'); return true; }
    F.download(`${F.slug(d0())}_para_nexus.json`, E.toNexusBackup([cap]), 'application/json');
    toast('📦 Nexus sem ponte ativa — baixei o pacote .json para importar no Nexus', 5200);
    return false;
  }
  const d0 = () => S.doc?.title || 'captura';

  F.panels.nexus = {
    title: '🔗 Nexus Capture', render(body) {
      body.innerHTML = `
        <div id="nxStatus" class="status">⏳ Verificando conexão com o Nexus Capture…</div>
        <h3>Enviar</h3>
        <button class="btn primary wide" data-act="send" ${S.doc ? '' : 'disabled'}>🔗 Enviar ${S.view === 'transcript' ? 'transcrição' : 'texto'} + marcações ao Nexus</button>
        <button class="btn wide" data-act="pkg" ${S.doc ? '' : 'disabled'}>📦 Baixar pacote Nexus (.json)</button>
        <h3>Receber</h3>
        <button class="btn wide" data-act="open">📂 Abrir backup/captura do Nexus no leitor limpo</button>
        <p class="hint">Aceita o arquivo <code>NEXUS_CAPTURE_BACKUP_*.json</code> e transcrições exportadas pelo Nexus (SRT, VTT, TXT…).</p>
        <details><summary style="cursor:pointer;color:var(--ui-dim);font-size:13px">⚙️ Avançado</summary>
          <div style="display:grid;gap:8px;margin-top:8px">
            <label style="font-size:12.5px;color:var(--ui-dim)">ID da extensão Nexus Capture</label>
            <input type="text" data-k="nexusId" value="${esc(S.prefs.nexusId || 'phmopnnkindeomkddkfjipjmnmhcemoo')}">
            <label style="font-size:12.5px;color:var(--ui-dim)">ID fixo deste FocusAI (para configurar no Nexus)</label>
            <input type="text" readonly value="${chrome.runtime.id}">
            <p class="hint">A ligação direta exige que o Nexus Capture tenha a ponte instalada (ver <code>docs/PONTE-NEXUS.md</code>). Sem ela, o FocusAI usa o pacote .json automaticamente.</p>
          </div></details>`;
      const st = $('#nxStatus', body);
      chrome.runtime.sendMessage({ type: 'FAI_NEXUS_PING' }).then(r => {
        if (r?.ok) { st.className = 'status ok'; st.innerHTML = `✅ Nexus Capture conectado${r.version ? ` · v${esc(r.version)}` : ''}. Envio direto ativo.`; }
        else { st.className = 'status warn'; st.innerHTML = `⚠️ ${esc(r?.error || 'Sem resposta')}<br>➡️ Use o <b>pacote .json</b> (funciona sempre) ou instale a ponte no Nexus.`; }
      });
      body.addEventListener('input', e => { if (e.target.dataset.k === 'nexusId') { S.prefs.nexusId = e.target.value.trim(); F.savePrefs(); } });
      body.addEventListener('click', e => {
        const act = e.target.closest('[data-act]')?.dataset.act;
        if (act === 'send') sendToNexus();
        if (act === 'pkg') { F.download(`${F.slug(d0())}_para_nexus.json`, E.toNexusBackup([currentCapture()]), 'application/json'); toast('📦 Pacote Nexus baixado'); }
        if (act === 'open') pickFile();
      });
    }
  };

  // ═════════ Exportar ═════════
  F.panels.export = {
    title: '⬇ Exportar', render(body) {
      body.innerHTML = `
        <h3>Documento</h3>
        <div class="grid2"><button class="btn" data-act="md">📝 Markdown</button><button class="btn" data-act="txt">📄 Texto</button><button class="btn" data-act="html">🌐 HTML limpo</button><button class="btn" data-act="print">🖨 PDF / Imprimir</button></div>
        <p class="hint">O Markdown inclui o texto e, no fim, suas marcações e anotações.</p>
        <h3>Marcações</h3>
        <div class="grid2"><button class="btn" data-act="marks">🖍 Só marcações (.md)</button><button class="btn" data-act="copy">📋 Copiar marcações</button></div>
        <h3>Guardar</h3>
        <button class="btn wide" data-act="pin">📌 Salvar na biblioteca para ler depois</button>
        <button class="btn wide" data-act="lib">📚 Abrir biblioteca</button>`;
      body.addEventListener('click', e => {
        const act = e.target.closest('[data-act]')?.dataset.act; if (!act || !S.doc) return;
        const base = F.slug(S.doc.title);
        if (act === 'md') F.download(`${base}.md`, `${htmlToMd(F.docEl)}\n\n---\n\n${marksMarkdown()}`);
        if (act === 'txt') F.download(`${base}.txt`, F.docEl.innerText);
        if (act === 'html') F.download(`${base}.html`, `<!doctype html><meta charset="utf-8"><title>${esc(S.doc.title)}</title><style>body{font:19px/1.8 Georgia,serif;max-width:68ch;margin:40px auto;padding:0 20px;color:#222}img{max-width:100%}</style>${F.docEl.innerHTML}`, 'text/html');
        if (act === 'print') { F.closePanel(); setTimeout(() => window.print(), 250); }
        if (act === 'marks') F.download(`${base}_marcacoes.md`, marksMarkdown());
        if (act === 'copy') navigator.clipboard.writeText(marksMarkdown()).then(() => toast('📋 Marcações copiadas'));
        if (act === 'pin') { S.record.pinned = true; F.persist(true); toast('📌 Salvo na biblioteca'); }
        if (act === 'lib') window.open(chrome.runtime.getURL('reader.html?view=library'), '_blank');
      });
    }
  };

  function htmlToMd(root) {
    const out = [];
    const inline = el => [...el.childNodes].map(n => n.nodeType === 3 ? n.data : n.matches?.('.ts') ? `**[${n.textContent}]** ` : n.matches?.('b.bio') ? n.textContent : /^(B|STRONG)$/.test(n.tagName) ? `**${inline(n)}**` : /^(I|EM)$/.test(n.tagName) ? `_${inline(n)}_` : n.tagName === 'A' ? `[${inline(n)}](${n.href})` : n.tagName === 'BR' ? '\n' : n.tagName === 'IMG' ? `![${n.alt || ''}](${n.src})` : inline(n)).join('').replace(/[ \t]+/g, ' ');
    for (const el of root.children) {
      const t = el.tagName;
      if (/^H[1-4]$/.test(t)) out.push(`${'#'.repeat(+t[1])} ${el.textContent.trim()}`);
      else if (t === 'UL' || t === 'OL') out.push([...el.children].map((li, i) => `${t === 'OL' ? `${i + 1}.` : '-'} ${inline(li).trim()}`).join('\n'));
      else if (t === 'BLOCKQUOTE') out.push(inline(el).trim().split('\n').map(l => `> ${l}`).join('\n'));
      else if (t === 'PRE') out.push('```\n' + el.textContent + '\n```');
      else if (t === 'TABLE') out.push([...el.querySelectorAll('tr')].map((tr, i) => { const row = '| ' + [...tr.children].map(c => c.textContent.trim().replace(/\|/g, '\\|')).join(' | ') + ' |'; return i === 0 ? row + '\n|' + [...tr.children].map(() => ' --- |').join('') : row; }).join('\n'));
      else if (el.textContent.trim() || el.querySelector('img')) out.push(inline(el).trim());
    }
    return out.join('\n\n');
  }

  // ═════════ Ajuda ═════════
  F.panels.help = {
    title: '? Atalhos', render(body) {
      const k = [['1–9', 'Aplicar estilo de caneta na seleção'], ['H', 'Marcar seleção com o estilo ativo'], ['P', 'Travar caneta (seleção já marca)'], ['E', 'Borracha'], ['T', 'Leitura e fonte'], ['M', 'Marcações'], ['I', 'Índice'], ['V', 'Transcrição'], ['N', 'Nexus Capture'], ['X', 'Exportar'], ['F', 'Modo foco'], ['S', 'Holofote no parágrafo'], ['J / K', 'Próximo / anterior parágrafo'], ['R', 'Régua de leitura'], ['B', 'Leitura biônica'], ['+ / −', 'Fonte maior / menor'], ['Esc', 'Fechar painel / sair']];
      body.innerHTML = `<div class="keys">${k.map(([a, b]) => `<kbd>${a}</kbd><span>${b}</span>`).join('')}</div>
        <h3>Como marcar com fluidez</h3><p class="hint">1. Escolha a cor na paleta à esquerda.<br>2. Aperte <kbd>P</kbd> para travar a caneta.<br>3. Agora é só arrastar sobre o texto — cada seleção vira marcação na hora.<br>4. Clique numa marcação para anotar, trocar a cor ou apagar.</p>
        <p class="hint">FocusAI 360X v${E.VERSION} · ID ${chrome.runtime.id}</p>`;
    }
  };

  // ═════════ Arquivos (PDF, transcrições, Nexus, texto) ═════════
  function pickFile() { const inp = $('#filePick'); inp.value = ''; inp.click(); }
  $('#filePick').addEventListener('change', e => { const f = e.target.files?.[0]; if (f) openFile(f); });
  document.addEventListener('dragover', e => { e.preventDefault(); $('.drop')?.classList.add('over'); });
  document.addEventListener('dragleave', () => $('.drop')?.classList.remove('over'));
  document.addEventListener('drop', e => { e.preventDefault(); $('.drop')?.classList.remove('over'); const f = e.dataTransfer.files?.[0]; if (f) openFile(f); });

  async function openFile(file) {
    const name = file.name.toLowerCase();
    try {
      if (name.endsWith('.pdf')) return openPdfBytes(new Uint8Array(await file.arrayBuffer()), file.name.replace(/\.pdf$/i, ''), '');
      const text = await file.text();
      if (/\.(html?|htm)$/.test(name)) return F.loadDoc({ kind: 'file', title: file.name, html: text });
      if (name.endsWith('.md')) return F.loadDoc({ kind: 'file', title: file.name.replace(/\.md$/, ''), html: mdToHtml(text) });
      const parsed = E.parseAny(text, name);
      if (parsed.nexus) return showNexusBackup(parsed.nexus);
      const segs = parsed.segments || [];
      const timed = segs.filter(s => !s.untimed).length;
      if (timed >= 2) {
        if (F.S.doc && F.EMBED) { F.setSegments(segs, { title: parsed.title }); toast(`✅ ${segs.length} trechos importados`); return; }
        return F.loadDoc({ kind: 'transcript', title: parsed.title || file.name.replace(/\.[^.]+$/, ''), url: parsed.url || '', segments: segs }, { view: 'transcript' });
      }
      return F.loadDoc({ kind: 'file', title: file.name, html: text.split(/\n{2,}/).map(p => `<p>${esc(p.trim())}</p>`).join('') });
    } catch (err) { toast(`⚠️ Não consegui abrir: ${err.message}`, 5000); }
  }

  function mdToHtml(md) {
    const inl = s => esc(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>').replace(/(^|\W)_(.+?)_(?=\W|$)/g, '$1<em>$2</em>').replace(/\[(.+?)\]\((https?:[^)]+)\)/g, '<a href="$2">$1</a>');
    return md.replace(/\r/g, '').split(/\n{2,}/).map(b => {
      const h = b.match(/^(#{1,4})\s+(.*)/); if (h) return `<h${h[1].length}>${inl(h[2])}</h${h[1].length}>`;
      if (/^\s*[-*]\s/.test(b)) return `<ul>${b.split('\n').map(l => `<li>${inl(l.replace(/^\s*[-*]\s+/, ''))}</li>`).join('')}</ul>`;
      if (/^\s*\d+\.\s/.test(b)) return `<ol>${b.split('\n').map(l => `<li>${inl(l.replace(/^\s*\d+\.\s+/, ''))}</li>`).join('')}</ol>`;
      if (/^>/.test(b)) return `<blockquote>${inl(b.replace(/^>\s?/gm, ''))}</blockquote>`;
      return `<p>${inl(b).replace(/\n/g, '<br>')}</p>`;
    }).join('\n');
  }

  function showNexusBackup(backup) {
    const caps = backup.captures || [];
    if (caps.length === 1) return openCapture(caps[0]);
    homeShell(`<h1>📦 Backup do Nexus Capture</h1><p class="sub">${caps.length} capturas · escolha uma para ler no modo limpo</p>
      <div class="lib">${caps.map((c, i) => `<div class="row" data-i="${i}"><span class="k">${c.transcript || c.kind === 'transcript' ? '🎙' : '📄'}</span><div><div class="tt">${esc(c.title || 'Sem título')}</div><div class="u">${esc(c.source || '')}</div></div><span class="c">${c.stats?.words || ''} palavras</span><span></span></div>`).join('')}</div>`);
    $('.lib').addEventListener('click', e => { const r = e.target.closest('.row[data-i]'); if (r) openCapture(caps[+r.dataset.i]); });
  }
  function openCapture(cap) {
    const d = E.fromNexusCapture(cap);
    if (d.kind === 'transcript') return F.loadDoc({ kind: 'transcript', title: d.title, url: d.url, segments: d.segments }, { view: 'transcript' });
    return F.loadDoc({ kind: 'nexus', title: d.title, url: d.url, html: d.html });
  }

  // PDF → texto limpo (PDF.js)
  async function openPdfBytes(bytes, title, url) {
    homeShell(`<h1>📄 Preparando PDF…</h1><p class="sub" id="pdfProg">Extraindo texto</p>`);
    const pdfjs = await import(chrome.runtime.getURL('vendor/pdfjs/pdf.mjs'));
    pdfjs.GlobalWorkerOptions.workerSrc = chrome.runtime.getURL('vendor/pdfjs/pdf.worker.mjs');
    const pdf = await pdfjs.getDocument({ data: bytes }).promise;
    const parts = [];
    for (let p = 1; p <= pdf.numPages; p++) {
      $('#pdfProg') && ($('#pdfProg').textContent = `Página ${p} de ${pdf.numPages}`);
      const page = await pdf.getPage(p); const tc = await page.getTextContent();
      const lines = [];
      for (const it of tc.items) {
        if (!it.str?.trim() && !it.hasEOL) continue;
        const y = Math.round(it.transform[5]), h = Math.abs(it.transform[3]) || it.height || 10;
        let line = lines.find(l => Math.abs(l.y - y) < h * 0.5);
        if (!line) lines.push(line = { y, h, items: [] });
        line.items.push({ x: it.transform[4], s: it.str }); line.h = Math.max(line.h, h);
      }
      lines.sort((a, b) => b.y - a.y);
      const hs = lines.map(l => l.h).sort((a, b) => a - b); const bodyH = hs[Math.floor(hs.length / 2)] || 10;
      const gaps = lines.slice(1).map((l, i) => lines[i].y - l.y).filter(g => g > 0).sort((a, b) => a - b); const gap = gaps[Math.floor(gaps.length / 4)] || bodyH * 1.3;
      let para = '';
      const flush = () => { if (para.trim()) parts.push(`<p>${esc(para.trim())}</p>`); para = ''; };
      lines.forEach((l, i) => {
        const text = l.items.sort((a, b) => a.x - b.x).map(x => x.s).join(' ').replace(/\s+/g, ' ').trim(); if (!text) return;
        const prevGap = i ? lines[i - 1].y - l.y : 0;
        if (l.h > bodyH * 1.25 && text.length < 140) { flush(); parts.push(`<h${l.h > bodyH * 1.6 ? 2 : 3}>${esc(text)}</h${l.h > bodyH * 1.6 ? 2 : 3}>`); return; }
        if (i && prevGap > gap * 1.45) flush();
        para = para.endsWith('-') && /^\p{Ll}/u.test(text) ? para.slice(0, -1) + text : (para ? `${para} ${text}` : text);
      });
      flush();
      if (p < pdf.numPages) parts.push(`<hr>`);
    }
    return F.loadDoc({ kind: 'pdf', title: title || 'PDF', url, html: parts.join('\n') || '<p><em>Este PDF não tem texto selecionável (é imagem escaneada).</em></p>' });
  }

  // ═════════ Biblioteca / início ═════════
  function homeShell(inner) {
    F.app.dataset.mode = 'home'; delete F.app.dataset.loading; F.S.doc = null;
    $('#docTitle').textContent = 'Biblioteca'; $('#meta').textContent = ''; $('#viewTabs').hidden = true;
    F.docEl.innerHTML = `<div class="home">${inner}</div>`; F.applyTypography();
  }
  async function showLibrary() {
    const all = await chrome.storage.local.get(null);
    const docs = Object.entries(all).filter(([k]) => k.startsWith('fai8:doc:')).map(([, v]) => v).sort((a, b) => (b.updated || 0) - (a.updated || 0));
    const icon = d => d.kind === 'transcript' || d.segments?.length ? '🎙' : d.kind === 'pdf' ? '📕' : d.kind === 'nexus' ? '🔗' : '📄';
    const count = d => Object.values(d.marks || {}).reduce((a, b) => a + (b?.length || 0), 0);
    homeShell(`<h1>📚 FocusAI 360X</h1><p class="sub">Leitor limpo · TDAH e dislexia · v${E.VERSION}</p>
      <div class="drop">📂 <b>Arraste aqui</b> um PDF, transcrição (SRT, VTT, JSON, TXT…), backup do Nexus, Markdown ou HTML<br><br><button class="btn primary" id="homePick">Escolher arquivo</button></div>
      <input type="search" id="libSearch" placeholder="🔎 Buscar na biblioteca (${docs.length})">
      <div class="lib" id="libList"></div>
      <p class="sub" style="margin-top:22px;font-size:13px">Dica: em qualquer página, clique no ícone do FocusAI (ou <kbd>Control</kbd>+<kbd>Shift</kbd>+<kbd>F</kbd>) para abrir o leitor limpo.</p>`);
    const list = $('#libList');
    const draw = q => {
      const f = docs.filter(d => !q || `${d.title} ${d.url}`.toLowerCase().includes(q.toLowerCase()));
      list.innerHTML = f.length ? f.map(d => `<div class="row" data-k="${esc(d.key)}"><span class="k">${icon(d)}</span><div><div class="tt">${esc(d.title || 'Sem título')}</div><div class="u">${esc(d.url || '')}</div></div><span class="c">${count(d)} 🖍 · ${new Date(d.updated || d.created).toLocaleDateString('pt-BR')}</span><button class="del" data-del="${esc(d.key)}" title="Remover">🗑</button></div>`).join('') : '<p class="sub">Nada salvo ainda. Marcações e transcrições aparecem aqui automaticamente.</p>';
    };
    draw('');
    $('#libSearch').addEventListener('input', e => draw(e.target.value));
    $('#homePick').addEventListener('click', pickFile);
    list.addEventListener('click', async e => {
      const del = e.target.closest('[data-del]');
      if (del) { if (confirm('Remover da biblioteca (marcações incluídas)?')) { await F.store.del(`fai8:doc:${del.dataset.del}`); showLibrary(); } return; }
      const row = e.target.closest('.row[data-k]'); if (!row) return;
      const d = docs.find(x => x.key === row.dataset.k);
      F.loadDoc({ key: d.key, kind: d.kind, title: d.title, url: d.url, html: d.html || '', segments: d.segments || null }, { view: d.html ? 'article' : 'transcript' });
    });
  }

  // ═════════ Arranque ═════════
  F.on('boot', async () => {
    const t = F.params.get('t'), pdf = F.params.get('pdf');
    try {
      if (t) {
        const r = await chrome.runtime.sendMessage({ type: 'FAI_TAKE', token: t });
        const p = r?.payload;
        if (!p) return showLibrary().then(() => toast('⚠️ Conteúdo expirado — abra de novo pela página.', 5000));
        if (p.kind === 'page') return F.loadDoc({ kind: 'page', title: p.title, url: p.url, byline: p.byline, html: p.html, video: p.video }, { view: 'article' }).then(() => { if (p.video && F.EMBED) setTimeout(() => toast('🎙 Vídeo detectado — aperte V para extrair a transcrição'), 600); });
        if (p.kind === 'transcript') return F.loadDoc({ kind: 'transcript', title: p.title, url: p.url, segments: E.merge(p.segments) }, { view: 'transcript' });
        if (p.kind === 'nexus-capture') return openCapture(p.capture);
        if (p.kind === 'nexus-backup') return showNexusBackup(typeof p.backup === 'string' ? JSON.parse(p.backup) : p.backup);
      }
      if (pdf) {
        const meta = (await chrome.storage.local.get(`fai8:pdfmeta:${pdf}`))[`fai8:pdfmeta:${pdf}`];
        const r = await chrome.runtime.sendMessage({ type: 'FAI_PDF_BYTES', id: pdf });
        if (r?.ok) { const bin = atob(r.b64); const bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i); return openPdfBytes(bytes, meta?.title, meta?.url); }
        await showLibrary(); return toast(`⚠️ Não consegui baixar o PDF${meta?.error ? ` (${meta.error})` : ''}. Baixe-o e arraste aqui.`, 7000);
      }
      return showLibrary();
    } catch (err) { console.error(err); showLibrary(); toast(`⚠️ ${err.message}`, 5000); }
  });
})();
