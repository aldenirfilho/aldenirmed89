/* FocusAI 360X v8.0.0 — service worker (MV3) */
'use strict';

const VERSION = '8.0.0';
const DEFAULT_NEXUS_ID = 'phmopnnkindeomkddkfjipjmnmhcemoo';
const BLOCKED = new Set(['chrome:', 'edge:', 'about:', 'view-source:', 'devtools:', 'chrome-extension:']);
const PDF_CACHE = 'fai8-pdf';
const OFFSCREEN = 'offscreen.html';
const stash = new Map();
let recordingTabId = null;
let creatingOffscreen = null;

// ───────── instalação e menus ─────────
chrome.runtime.onInstalled.addListener(() => {
  chrome.action.setBadgeBackgroundColor({ color: '#C9A227' }).catch(() => {});
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({ id: 'fai-open', title: '📖 Abrir no leitor limpo FocusAI', contexts: ['page'] });
    chrome.contextMenus.create({ id: 'fai-open-sel', title: '📖 Abrir seleção no leitor limpo', contexts: ['selection'] });
    chrome.contextMenus.create({ id: 'fai-library', title: '📚 Biblioteca FocusAI (marcações e transcrições)', contexts: ['action'] });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId === 'fai-library') return openReaderTab('view=library');
  if (!tab?.id) return;
  if (info.menuItemId === 'fai-open') return activate(tab, { mode: 'article' });
  if (info.menuItemId === 'fai-open-sel') return activate(tab, { mode: 'selection' });
});

chrome.action.onClicked.addListener(tab => activate(tab, { mode: 'toggle' }));

async function activate(tab, opts) {
  if (!tab?.id || !tab.url) return;
  let u; try { u = new URL(tab.url); } catch { return; }
  if (BLOCKED.has(u.protocol)) return openReaderTab('view=library');
  if (await isPdf(tab)) return openPdf(tab);
  try {
    const ping = await chrome.tabs.sendMessage(tab.id, { type: 'FAI_PING' }).catch(() => null);
    if (ping?.version !== VERSION) {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ['js/engine.js', 'vendor/readability/Readability.js', 'js/content.js'] });
    }
    await chrome.tabs.sendMessage(tab.id, { type: 'FAI_ACTIVATE', ...opts });
  } catch (err) {
    console.warn('[FocusAI] falha ao injetar', err);
    flash(tab.id, '!', '#D94C4C');
  }
}

function openReaderTab(query) {
  return chrome.tabs.create({ url: chrome.runtime.getURL(`reader.html${query ? '?' + query : ''}`) });
}

// ───────── PDF ─────────
async function isPdf(tab) {
  const url = tab.url || '';
  if (/\.pdf($|[?#])/i.test(url)) return true;
  if (!/^https?:/i.test(url)) return false;
  try {
    const r = await fetch(url, { method: 'HEAD', credentials: 'include', cache: 'no-store' });
    return (r.headers.get('content-type') || '').toLowerCase().includes('application/pdf');
  } catch { return false; }
}

async function openPdf(tab) {
  const id = crypto.randomUUID();
  const meta = { id, url: tab.url, title: (tab.title || 'PDF').replace(/\.pdf$/i, ''), cached: false };
  try {
    const r = await fetch(tab.url, { credentials: 'include', cache: 'no-store' });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    const cache = await caches.open(PDF_CACHE);
    await cache.put(`https://fai.local/pdf/${id}`, new Response(await r.blob(), { headers: { 'content-type': 'application/pdf' } }));
    meta.cached = true;
  } catch (e) { meta.error = String(e?.message || e); }
  await chrome.storage.local.set({ [`fai8:pdfmeta:${id}`]: meta });
  return openReaderTab(`pdf=${encodeURIComponent(id)}`);
}

// ───────── mensagens internas ─────────
chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  const run = fn => { Promise.resolve().then(fn).then(reply, e => reply({ ok: false, error: String(e?.message || e) })); return true; };
  switch (msg?.type) {
    case 'FAI_STASH': return run(async () => {
      const token = crypto.randomUUID();
      stash.set(token, msg.payload);
      setTimeout(() => stash.delete(token), 30 * 60 * 1000);
      return { ok: true, token };
    });
    case 'FAI_TAKE': return run(async () => ({ ok: !!stash.get(msg.token), payload: stash.get(msg.token) || null }));
    case 'FAI_OPEN_TAB_WITH': return run(async () => {
      const token = crypto.randomUUID(); stash.set(token, msg.payload);
      await openReaderTab(`t=${token}`); return { ok: true };
    });
    case 'FAI_TAB_CMD': return run(async () => {
      const tabId = sender.tab?.id;
      if (!tabId) throw new Error('Este comando precisa da aba original (abra o leitor a partir da página).');
      return await chrome.tabs.sendMessage(tabId, msg.cmd, { frameId: 0 });
    });
    case 'FAI_FETCH_TEXT': return run(async () => {
      const url = new URL(msg.url);
      if (!/(^|\.)youtube\.com$|(^|\.)googlevideo\.com$/.test(url.hostname)) throw new Error('Origem não autorizada.');
      const r = await fetch(url.href, { credentials: 'include', cache: 'no-store' });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      return { ok: true, text: await r.text() };
    });
    case 'FAI_FETCH_DATAURL': return run(async () => {
      const r = await fetch(msg.url, { credentials: 'include' });
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      const blob = await r.blob();
      if (blob.size > 8 * 1024 * 1024) throw new Error('Imagem grande demais.');
      const buf = new Uint8Array(await blob.arrayBuffer()); let bin = '';
      for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      return { ok: true, dataUrl: `data:${blob.type || 'image/png'};base64,${btoa(bin)}` };
    });
    case 'FAI_PDF_BYTES': return run(async () => {
      const cache = await caches.open(PDF_CACHE);
      const r = await cache.match(`https://fai.local/pdf/${msg.id}`);
      if (!r) return { ok: false };
      const buf = new Uint8Array(await r.arrayBuffer()); let bin = '';
      for (let i = 0; i < buf.length; i += 0x8000) bin += String.fromCharCode.apply(null, buf.subarray(i, i + 0x8000));
      return { ok: true, b64: btoa(bin) };
    });
    case 'FAI_BADGE': if (sender.tab?.id) flash(sender.tab.id, msg.text || '', msg.color || '#C9A227'); reply({ ok: true }); return false;
    // Whisper local
    case 'FAI_WHISPER_HEALTH': return run(() => whisperHealth(msg.endpoint));
    case 'FAI_AUDIO_START': return run(() => audioStart(msg, sender));
    case 'FAI_AUDIO_STOP': return run(() => audioStop(sender));
    case 'FAI_AUDIO_CANCEL': return run(() => audioCancel(sender));
    case 'FAI_AUDIO_STATUS': if (msg.target === 'background') { relay(msg.tabId, { ...msg, target: undefined }); if (msg.status === 'error') recordingTabId = null; } reply({ ok: true }); return false;
    case 'FAI_AUDIO_RESULT': if (msg.target === 'background') { const t = msg.tabId || recordingTabId; recordingTabId = null; relay(t, { type: 'FAI_AUDIO_RESULT', result: msg.result }); flash(t, 'OK', '#188038'); } reply({ ok: true }); return false;
    // Nexus Capture
    case 'FAI_NEXUS_PING': return run(() => nexusSend({ type: 'NEXUS_PING', from: 'focusai-360x', version: VERSION }, 1500));
    case 'FAI_NEXUS_SEND': return run(() => nexusSend({ type: 'NEXUS_IMPORT_CAPTURE', from: 'focusai-360x', version: VERSION, capture: msg.capture }, 4000));
    default: return false;
  }
});

/** Repassa status do áudio para o leitor embutido (frames da aba) */
function relay(tabId, payload) {
  if (!tabId) return;
  chrome.tabs.sendMessage(tabId, payload).catch(() => {});
  chrome.runtime.sendMessage({ ...payload, relayTabId: tabId }).catch(() => {});
}

// ───────── Nexus Capture (ponte entre extensões) ─────────
async function nexusId() {
  const { 'fai8:prefs': p } = await chrome.storage.local.get('fai8:prefs');
  return (p?.nexusId || DEFAULT_NEXUS_ID).trim();
}

async function nexusSend(message, timeoutMs) {
  const id = await nexusId();
  const res = await Promise.race([
    chrome.runtime.sendMessage(id, message).then(r => r ?? { ok: false, error: 'Nexus Capture recebeu, mas não respondeu (ponte ainda não instalada nele).' })
      .catch(e => ({ ok: false, error: /Could not establish connection|Receiving end/i.test(String(e?.message)) ? 'Nexus Capture não encontrado ou sem a ponte FocusAI ativada.' : String(e?.message || e) })),
    new Promise(r => setTimeout(() => r({ ok: false, error: 'Nexus Capture não respondeu a tempo.' }), timeoutMs))
  ]);
  return { ...res, nexusId: id };
}

chrome.runtime.onMessageExternal.addListener((msg, sender, reply) => {
  (async () => {
    const allowed = [await nexusId()];
    if (!allowed.includes(sender.id)) return { ok: false, error: 'Extensão não autorizada.' };
    if (msg?.type === 'FOCUSAI_PING') return { ok: true, app: 'FocusAI 360X', version: VERSION, accepts: ['FOCUSAI_OPEN_CAPTURE', 'FOCUSAI_OPEN_TRANSCRIPT', 'FOCUSAI_OPEN_BACKUP'] };
    if (msg?.type === 'FOCUSAI_OPEN_CAPTURE' && msg.capture) { await openWith({ kind: 'nexus-capture', capture: msg.capture }); return { ok: true }; }
    if (msg?.type === 'FOCUSAI_OPEN_TRANSCRIPT' && Array.isArray(msg.segments)) { await openWith({ kind: 'transcript', title: msg.title, url: msg.url, segments: msg.segments }); return { ok: true }; }
    if (msg?.type === 'FOCUSAI_OPEN_BACKUP' && msg.backup) { await openWith({ kind: 'nexus-backup', backup: msg.backup }); return { ok: true }; }
    return { ok: false, error: 'Tipo de mensagem desconhecido.' };
  })().then(reply, e => reply({ ok: false, error: String(e?.message || e) }));
  return true;
});

async function openWith(payload) {
  const token = crypto.randomUUID(); stash.set(token, payload);
  await openReaderTab(`t=${token}`);
}

// ───────── Whisper local (áudio da aba) ─────────
async function whisperHealth(endpoint) {
  const base = String(endpoint || 'http://127.0.0.1:8765').replace(/\/$/, '');
  const c = new AbortController(); const t = setTimeout(() => c.abort(), 2500);
  try {
    const r = await fetch(`${base}/health`, { cache: 'no-store', signal: c.signal });
    const d = await r.json().catch(() => ({}));
    return r.ok && d?.ok ? { ok: true, data: d } : { ok: false, error: d?.error || `HTTP ${r.status}` };
  } catch (e) { return { ok: false, error: 'Whisper local desligado (rode companion/INICIAR-WHISPER-MAC.command).' }; }
  finally { clearTimeout(t); }
}

async function ensureOffscreen() {
  const url = chrome.runtime.getURL(OFFSCREEN);
  const ctx = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'], documentUrls: [url] });
  if (ctx.length) return;
  creatingOffscreen ||= chrome.offscreen.createDocument({ url: OFFSCREEN, reasons: ['USER_MEDIA', 'BLOBS'], justification: 'Gravar o áudio da aba para o Whisper local, após clique do usuário.' });
  try { await creatingOffscreen; } finally { creatingOffscreen = null; }
}

async function audioStart(msg, sender) {
  const tabId = sender.tab?.id;
  if (!tabId) throw new Error('Abra o leitor a partir da aba do vídeo.');
  if (recordingTabId !== null) throw new Error('Já existe uma gravação em andamento.');
  const h = await whisperHealth(msg.endpoint);
  if (!h.ok) throw new Error(h.error);
  await ensureOffscreen();
  const streamId = await chrome.tabCapture.getMediaStreamId({ targetTabId: tabId });
  recordingTabId = tabId;
  const r = await chrome.runtime.sendMessage({ target: 'offscreen', type: 'FAI_OFF_START', streamId, session: { tabId, endpoint: msg.endpoint, language: msg.language || 'auto', model: msg.model || 'small', title: sender.tab.title, url: sender.tab.url } });
  if (!r?.ok) { recordingTabId = null; throw new Error(r?.error || 'Falha ao iniciar a gravação.'); }
  flash(tabId, 'REC', '#D94C4C', true);
  return { ok: true };
}
async function audioStop(sender) {
  if (recordingTabId === null) throw new Error('Nenhuma gravação ativa.');
  return chrome.runtime.sendMessage({ target: 'offscreen', type: 'FAI_OFF_STOP', tabId: sender.tab?.id || recordingTabId });
}
async function audioCancel(sender) {
  await chrome.runtime.sendMessage({ target: 'offscreen', type: 'FAI_OFF_CANCEL' }).catch(() => {});
  const t = sender.tab?.id || recordingTabId; recordingTabId = null; flash(t, '', '#C9A227');
  return { ok: true };
}

async function flash(tabId, text, color, sticky = false) {
  if (!tabId) return;
  try {
    await chrome.action.setBadgeBackgroundColor({ tabId, color });
    await chrome.action.setBadgeText({ tabId, text });
    if (text && !sticky) setTimeout(() => chrome.action.setBadgeText({ tabId, text: '' }).catch(() => {}), 2200);
  } catch {}
}
