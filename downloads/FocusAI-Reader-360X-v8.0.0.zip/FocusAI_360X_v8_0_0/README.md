# 📖 FocusAI Reader 360X — v8.0.0 (16/11/2026)

Leitor limpo para **TDAH grave e dislexia**, em uma extensão do Chrome.
Um clique no ícone transforma a página num texto calmo, sem propaganda e sem menus, com **OpenDyslexic**, marca-texto e sublinhado personalizáveis, transcrição de vídeos e ponte com o **Nexus Capture**.

## 🚀 Instalar (≈3 min)

1. Descompacte o ZIP e guarde a pasta num lugar fixo (ex.: `~/Documents/Extensoes/`).
2. No Chrome, abra `chrome://extensions` e ligue o **Modo do desenvolvedor**.
3. **Remova** a versão antiga do FocusAI (v7.x), para os atalhos não brigarem.
4. Clique em **Carregar sem compactação** e escolha a pasta `FocusAI_360X_v8_0_0`.
5. Fixe o ícone na barra (🧩 → 📌).
6. Para PDFs locais: em **Detalhes**, ligue **Permitir acesso a URLs de arquivo**.

**Atalho:** `Control + Shift + F` no Mac abre e fecha o leitor.
**ID fixo da extensão:** `legpmejabkphjdmkemblaeoccdcmpkak` (é o mesmo em qualquer pasta ou Mac).

## 🧭 Uso em 30 segundos

| Quero… | Faço… |
|---|---|
| Ler limpo | Clique no ícone (ou `Ctrl+Shift+F`) |
| Marcar rápido | Escolha a cor na paleta à esquerda → `P` (trava a caneta) → arraste no texto |
| Marcar com escolha | Selecione o texto → clique na cor da barra que aparece |
| Anotar | Clique numa marcação → escreva (salva sozinho) |
| Apagar | `E` (borracha) → clique na marcação |
| Mudar fonte e espaços | `T` (OpenDyslexic, Lexend, Atkinson…) |
| Transcrever vídeo | Abra o leitor na aba do vídeo → `V` → ⚡ Extrair |
| Mandar ao Nexus | `N` → Enviar (ou baixar o pacote .json) |
| Ler um PDF | Abra o PDF e clique no ícone, ou arraste o arquivo na Biblioteca |

Todos os atalhos: tecla `?` dentro do leitor.

## 🧩 O que mudou em relação à v7.1.1

- **Código ~60% menor:** o `content.js` de 317 KB virou módulos pequenos (página ≈ 16 KB, leitor ≈ 80 KB).
- **Leitor isolado num iframe da própria extensão:** o CSS do site não interfere, e não há mais “pisca-pisca” ao marcar.
- **Marcação nova (CSS Custom Highlight API):** não altera o texto da página, então não trava, não pisca e sobrevive a mudar fonte, tema, leitura biônica e quebra de parágrafos.
- Até **9 estilos de caneta** editáveis: cor, opacidade, tipo (marca-texto, sublinhado, marca-texto + sublinhado, texto colorido), linha (reta, dupla, ondulada, pontilhada, tracejada) e espessura.
- **Transcrição** em cascata (YouTube → painel → VTT → painel do Drive), legendas ao vivo, Whisper local, importação de 8 formatos e exportação em TXT, MD, SRT, VTT, JSON e **Nexus**.
- **Ponte com o Nexus Capture** (envio direto ou pacote .json no formato de backup do Nexus).
- Saíram da v7 (para simplificar): calculadoras clínicas, flashcards, tradução, sons ambientes, pomodoro e o visualizador de PDF com páginas. O PDF agora vira **texto limpo** no mesmo leitor.

## 📁 Arquivos

```
manifest.json          configuração (MV3, ID fixo)
background.js          ícone, PDF, Whisper, ponte Nexus
js/content.js          extração da página, vídeo e transcrição
js/engine.js           conversores de legenda e formato Nexus
js/reader-core.js      leitor, tipografia, marcações
js/reader-panels.js    painéis, biblioteca, PDF, exportação
reader.html / .css     interface do leitor
offscreen.*            gravação do áudio da aba (Whisper)
companion/             Whisper local opcional (Mac)
docs/PONTE-NEXUS.md    como ligar ao Nexus Capture
```

## 🔒 Privacidade

Tudo fica no seu Chrome (`chrome.storage.local`). Nada é enviado para servidores; o Whisper roda só em `127.0.0.1`.
