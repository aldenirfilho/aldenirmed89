# Licenças de terceiros

| Componente | Licença | Arquivo |
|---|---|---|
| OpenDyslexic (Abbie Gonzalez) | SIL Open Font License 1.1 | vendor/fonts/OpenDyslexic-LICENSE.txt |
| Lexend | SIL Open Font License 1.1 | — |
| Atkinson Hyperlegible (Braille Institute) | SIL Open Font License 1.1 | — |
| Mozilla Readability | Apache 2.0 | vendor/LICENSE-READABILITY.md |
| PDF.js 5.4.624 (Mozilla) | Apache 2.0 | vendor/LICENSE-PDFJS.txt |

As fontes OFL podem ir dentro de software (inclusive pago), mas não podem ser vendidas sozinhas.
O companion Whisper (faster-whisper, CTranslate2, Flask, FFmpeg) é instalado à parte pelo usuário.
