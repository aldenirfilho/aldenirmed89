#!/bin/bash
set -e
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "Execute primeiro INSTALAR-WHISPER-MAC.command"
  read -r -p "Pressione Enter para fechar..."
  exit 1
fi
source .venv/bin/activate
export FOCUSAI_WHISPER_MODEL="${FOCUSAI_WHISPER_MODEL:-small}"
python focusai_whisper_server.py
