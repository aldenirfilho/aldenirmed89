#!/usr/bin/env python3
"""FocusAI Whisper Local Companion v1.0 — servidor local em 127.0.0.1."""
from __future__ import annotations

import os
import tempfile
from pathlib import Path
from flask import Flask, jsonify, request
from flask_cors import CORS
from faster_whisper import WhisperModel

HOST = "127.0.0.1"
PORT = int(os.environ.get("FOCUSAI_WHISPER_PORT", "8765"))
DEFAULT_MODEL = os.environ.get("FOCUSAI_WHISPER_MODEL", "small")
DEVICE = os.environ.get("FOCUSAI_WHISPER_DEVICE", "auto")
COMPUTE = os.environ.get("FOCUSAI_WHISPER_COMPUTE", "int8")
MAX_MB = int(os.environ.get("FOCUSAI_WHISPER_MAX_MB", "2048"))

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = MAX_MB * 1024 * 1024
CORS(app, resources={r"/*": {"origins": "*"}})
models: dict[str, WhisperModel] = {}


def get_model(name: str) -> WhisperModel:
    clean = (name or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    if clean not in models:
        models[clean] = WhisperModel(clean, device=DEVICE, compute_type=COMPUTE)
    return models[clean]


@app.get("/health")
def health():
    return jsonify(ok=True, service="FocusAI Whisper Local", default_model=DEFAULT_MODEL, device=DEVICE)


@app.post("/transcribe")
def transcribe():
    upload = request.files.get("file")
    if not upload:
        return jsonify(ok=False, error="Arquivo de áudio ausente."), 400
    language = (request.form.get("language") or "auto").strip()
    model_name = (request.form.get("model") or DEFAULT_MODEL).strip()
    suffix = Path(upload.filename or "capture.webm").suffix or ".webm"
    temp_path = None
    try:
        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            upload.save(tmp)
            temp_path = tmp.name
        model = get_model(model_name)
        segments_iter, info = model.transcribe(
            temp_path,
            language=None if language in {"", "auto"} else language,
            vad_filter=True,
            beam_size=5,
            word_timestamps=False,
            condition_on_previous_text=True,
        )
        segments = []
        for index, seg in enumerate(segments_iter, 1):
            text = (seg.text or "").strip()
            if text:
                segments.append({"id": f"w-{index}", "start": float(seg.start), "end": float(seg.end), "text": text})
        return jsonify(
            ok=True,
            provider="whisper-local",
            model=model_name,
            language=getattr(info, "language", language),
            language_probability=float(getattr(info, "language_probability", 0) or 0),
            duration=float(getattr(info, "duration", 0) or 0),
            segments=segments,
            text=" ".join(item["text"] for item in segments),
        )
    except Exception as exc:  # noqa: BLE001
        return jsonify(ok=False, error=str(exc)), 500
    finally:
        if temp_path:
            try:
                os.unlink(temp_path)
            except OSError:
                pass


if __name__ == "__main__":
    print(f"FocusAI Whisper Local em http://{HOST}:{PORT}")
    app.run(host=HOST, port=PORT, debug=False, threaded=True)
