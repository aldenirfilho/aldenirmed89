#!/bin/bash
set -e
cd "$(dirname "$0")"
echo "🚀 Instalando FocusAI Whisper Local..."
if ! command -v brew >/dev/null 2>&1; then
  echo "Homebrew não encontrado. Instale em https://brew.sh e execute novamente."
  exit 1
fi
brew list ffmpeg >/dev/null 2>&1 || brew install ffmpeg
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install faster-whisper flask flask-cors
chmod +x INICIAR-WHISPER-MAC.command
echo "✅ Instalado. Dê dois cliques em INICIAR-WHISPER-MAC.command."
read -r -p "Pressione Enter para fechar..."
