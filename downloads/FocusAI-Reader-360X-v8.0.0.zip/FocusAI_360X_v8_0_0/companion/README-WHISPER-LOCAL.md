# FocusAI Whisper Local

Este módulo opcional transcreve o áudio da aba **localmente no Mac**, sem enviar o conteúdo a um serviço externo.

1. Execute `INSTALAR-WHISPER-MAC.command` uma única vez.
2. Depois, execute `INICIAR-WHISPER-MAC.command` antes de transcrever áudio sem legendas.
3. No FocusAI, abra **Transcrição → Testar Whisper local**.
4. Coloque o vídeo no início e clique em **Gravar áudio inteiro**.
5. Mantenha o vídeo reproduzindo. A gravação ocorre em tempo real.

O modelo padrão é `small`. Para maior precisão, abra o Terminal e use:

```bash
export FOCUSAI_WHISPER_MODEL=medium
./INICIAR-WHISPER-MAC.command
```

O servidor escuta somente em `127.0.0.1:8765`.
