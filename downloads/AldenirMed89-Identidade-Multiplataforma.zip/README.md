# AldenirMed89 · Aeroespacial · 2026-09-08

Logotipo aeroespacial original: A branco, órbita ciano e ponto âmbar. Ícones derivados por redimensionamento; desenho preservado.

- macOS: ICNS para personalizar um atalho; Safari → Arquivo → Adicionar ao Dock usa o ícone do site.
- iOS/iPadOS: PNG 120, 152, 167, 180 e 1024 px; Safari → Compartilhar → Adicionar à Tela de Início.
- Windows: ICO com 16, 24, 32, 48, 64, 128 e 256 px; use Propriedades do atalho → Alterar ícone.
- Android: PNG 192 e 512 px com purpose any; o navegador preserva o desenho completo.

Site: https://aldenirfilho.github.io/aldenirmed89/
Este pacote contém imagens, não aplicativos nativos. Atalhos existentes podem manter o ícone em cache.
